// Health / Body screen
function HealthScreen() {
  const b = DATA.body;
  const [tab, setTab] = useState('inbody');
  const [logOpen, setLogOpen] = useState(false);

  return (
    <>
      <div className="scroll">
        <div className="app-header">
          <div className="head-left">
            <span className="head-eyebrow">Salud · cuerpo & labs</span>
            <h1 style={{ fontSize: 36 }}>
              tu <span className="accent">cuerpo</span><br/>
              <span style={{ fontStyle: 'italic' }}>en datos</span>
            </h1>
          </div>
          <button className="icon-btn" onClick={() => setLogOpen(true)}>
            <Icon.Plus size={16}/>
          </button>
        </div>

        {/* WEIGHT TILE */}
        <div style={{ padding: '14px 18px 0' }}>
          <div className="card-gold" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', padding: 18 }}>
            <div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.7 }}>
                Peso actual
              </div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 56, lineHeight: 0.95, marginTop: 4, color: 'var(--ink)' }}>
                {b.weight.current}<span style={{ fontSize: 22, opacity: 0.6 }}>{b.weight.unit}</span>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 11, letterSpacing: '0.1em', color: 'var(--ink)', opacity: 0.7, marginTop: 4 }}>
                ↓ {Math.abs(b.weight.delta)} KG · 6 SEMANAS
              </div>
            </div>
            <div style={{ position: 'relative', width: 80, height: 80 }}>
              <svg viewBox="0 0 80 80" width="80" height="80">
                <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(91,28,46,0.2)" strokeWidth="6"/>
                <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(91,28,46,0.95)" strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 34}
                  strokeDashoffset={2 * Math.PI * 34 * (1 - 0.31)}
                  transform="rotate(-90 40 40)"
                />
              </svg>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', color: 'var(--ink)' }}>
                <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 18, lineHeight: 1 }}>31%</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 7.5, letterSpacing: '0.15em', opacity: 0.75 }}>META</div>
              </div>
            </div>
          </div>
        </div>

        {/* TABS: InBody / Medidas / Labs */}
        <div className="pad" style={{ marginTop: 16 }}>
          <div className="segmented">
            {[
              { v: 'inbody', l: 'inbody' },
              { v: 'medidas', l: 'medidas' },
              { v: 'labs', l: 'labs' },
            ].map(t => (
              <button key={t.v} className={tab === t.v ? 'active' : ''} onClick={() => setTab(t.v)}>
                {t.l}
              </button>
            ))}
          </div>
        </div>

        {tab === 'inbody' && (
          <div className="pad" style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {Object.entries(b.inbody).map(([k, v]) => {
              const labels = {
                fat: ['Grasa corporal', 'Grasa'],
                muscle: ['Masa muscular', 'Músculo'],
                water: ['Agua corporal', 'Agua'],
                visc: ['Grasa visceral', 'Visceral'],
              };
              const delta = (v.value - v.prev).toFixed(1);
              const isGoodMove = (v.good === 'up' && v.value > v.prev) || (v.good === 'down' && v.value < v.prev);
              return (
                <div key={k} className="card-dark" style={{ padding: 14 }}>
                  <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase' }}>
                    {labels[k][1]}
                  </div>
                  <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 28, color: 'var(--lavender)', lineHeight: 1, marginTop: 4 }}>
                    {v.value}<span style={{ fontSize: 12, opacity: 0.6 }}>{v.unit}</span>
                  </div>
                  <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, marginTop: 4, color: isGoodMove ? '#7BE2A8' : 'var(--rose-glow)', letterSpacing: '0.06em' }}>
                    {delta > 0 ? '↑' : '↓'} {Math.abs(delta)} vs ant.
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'medidas' && (
          <div className="pad" style={{ marginTop: 14 }}>
            <div className="card-dark" style={{ padding: '6px 14px' }}>
              {b.measures.map((m, i) => {
                const delta = (m.value - m.prev).toFixed(1);
                const good = m.value < m.prev;
                return (
                  <div key={i} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '14px 0', borderBottom: i < b.measures.length - 1 ? '1px solid var(--hairline-2)' : 'none',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{
                        width: 30, height: 30, borderRadius: 10,
                        background: 'rgba(247,217,252,0.08)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        <Icon.Ruler size={14}/>
                      </div>
                      <div>
                        <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 500 }}>{m.name}</div>
                        <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.05em', marginTop: 2 }}>
                          antes · {m.prev} {m.unit}
                        </div>
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--lavender)', lineHeight: 1 }}>
                        {m.value}<span style={{ fontSize: 11, opacity: 0.6 }}>{m.unit}</span>
                      </div>
                      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.08em', color: good ? '#7BE2A8' : 'var(--muted)', marginTop: 2 }}>
                        {delta == 0 ? '—' : (delta > 0 ? '↑ +' : '↓ ') + Math.abs(delta)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === 'labs' && (
          <div className="pad" style={{ marginTop: 14 }}>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 8 }}>
              Estudio · {b.labs[0].date} · vs feb 2026
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {b.labs.map((l, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '12px 14px', borderRadius: 14,
                  background: 'rgba(247,217,252,0.04)',
                  border: '1px solid var(--hairline-2)',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13.5, color: 'var(--lavender)', fontWeight: 500 }}>{l.name}</div>
                    <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--muted)', letterSpacing: '0.06em', marginTop: 2 }}>
                      RANGO {l.range}{l.unit && ` ${l.unit}`} · ANT {l.prev}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 20, color: 'var(--lavender)', lineHeight: 1 }}>
                      {l.value}<span style={{ fontSize: 9.5, opacity: 0.6, marginLeft: 2 }}>{l.unit}</span>
                    </div>
                    <span className={'lab-badge ' + l.status} style={{ marginTop: 4 }}>
                      {l.status === 'optimal' ? 'óptimo' : l.status === 'watch' ? 'observar' : l.status === 'low' ? 'bajo' : 'alto'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ padding: '18px 18px 0' }}>
          <button className="btn ghost btn-block" onClick={() => setLogOpen(true)}>
            <Icon.Plus size={14}/> Registrar medición de hoy
          </button>
        </div>
      </div>

      <Sheet open={logOpen} onClose={() => setLogOpen(false)} title="Nueva medición">
        <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase' }}>
          Martes · 12 mayo 2026
        </div>
        <div className="hairline"/>
        <Stepper label="Peso" unit="kg" defaultValue={70.1} step={0.1}/>
        <Stepper label="Cintura" unit="cm" defaultValue={78} step={0.5}/>
        <Stepper label="Cadera" unit="cm" defaultValue={102} step={0.5}/>
        <Stepper label="Muslo" unit="cm" defaultValue={58} step={0.5}/>
        <div className="row">
          <div className="row-main">
            <div className="row-title">¿Cómo te sientes?</div>
            <div className="row-sub">energía, ánimo, hambre</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['😴','😊','💪','🔥'].map((e, i) => (
              <button key={i} style={{
                width: 36, height: 36, borderRadius: 12, fontSize: 18,
                background: 'rgba(247,217,252,0.06)',
                border: '1px solid var(--hairline)',
              }}>{e}</button>
            ))}
          </div>
        </div>
        <button className="btn primary btn-block" style={{ marginTop: 12 }} onClick={() => setLogOpen(false)}>
          Guardar medición
        </button>
      </Sheet>
    </>
  );
}

function Stepper({ label, unit, defaultValue, step }) {
  const [v, setV] = useState(defaultValue);
  return (
    <div className="row">
      <div className="row-main">
        <div className="row-title">{label}</div>
        <div className="row-sub">en {unit}</div>
      </div>
      <div className="stepper">
        <button onClick={() => setV(x => +(x - step).toFixed(1))}>−</button>
        <div className="val">{v}</div>
        <button onClick={() => setV(x => +(x + step).toFixed(1))}>+</button>
      </div>
    </div>
  );
}

window.HealthScreen = HealthScreen;
