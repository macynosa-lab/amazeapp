// Icons + sparkles · Y2K hand-drawn feel
const Icon = {};

const stroke = 1.8;

Icon.Star4 = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 0 L14 10 L24 12 L14 14 L12 24 L10 14 L0 12 L10 10 Z" />
  </svg>
);

Icon.Sparkle = ({ size = 16, color = '#FAB940', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color} style={style}>
    <path d="M12 0 L13.5 10.5 L24 12 L13.5 13.5 L12 24 L10.5 13.5 L0 12 L10.5 10.5 Z" />
  </svg>
);

Icon.Bell = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 8 a6 6 0 0 1 12 0 c0 7 3 9 3 9 H3 s3 -2 3 -9z"/>
    <path d="M10 21 a2 2 0 0 0 4 0"/>
  </svg>
);

Icon.BellOff = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 4 a6 6 0 0 1 9 4 c0 4 1 7 2 9"/>
    <path d="M6 8 c0 7 -3 9 -3 9 h13"/>
    <path d="M10 21 a2 2 0 0 0 4 0"/>
    <line x1="2" y1="2" x2="22" y2="22"/>
  </svg>
);

Icon.Check = ({ size = 12, color = '#25104D' }) => (
  <svg width={size} height={size} viewBox="0 0 14 14" fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 7 L6 11 L12 3"/>
  </svg>
);

Icon.Plus = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2.4} strokeLinecap="round">
    <path d="M12 5 L12 19 M5 12 L19 12"/>
  </svg>
);

Icon.Pill = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke}>
    <rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(-30 12 12)"/>
    <line x1="9" y1="7" x2="15" y2="13" transform="rotate(-30 12 12)"/>
  </svg>
);

Icon.Dumbbell = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <rect x="2" y="8" width="3" height="8" rx="1"/>
    <rect x="19" y="8" width="3" height="8" rx="1"/>
    <rect x="6" y="10" width="2" height="4"/>
    <rect x="16" y="10" width="2" height="4"/>
    <line x1="8" y1="12" x2="16" y2="12"/>
  </svg>
);

Icon.Heart = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 21 s-7-5-9-10 a5 5 0 0 1 9-3 a5 5 0 0 1 9 3 c-2 5-9 10-9 10z"/>
  </svg>
);

Icon.Chart = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 17 L9 11 L13 15 L21 7"/>
    <path d="M14 7 L21 7 L21 14"/>
  </svg>
);

Icon.User = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <circle cx="12" cy="8" r="4"/>
    <path d="M4 21 c0-4 4-7 8-7 s8 3 8 7"/>
  </svg>
);

Icon.Sun = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <circle cx="12" cy="12" r="4"/>
    <path d="M12 2 v3 M12 19 v3 M2 12 h3 M19 12 h3 M5 5 l2 2 M17 17 l2 2 M5 19 l2-2 M17 7 l2-2"/>
  </svg>
);

Icon.Water = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2 c-4 6-6 9-6 13 a6 6 0 0 0 12 0 c0-4-2-7-6-13z"/>
  </svg>
);

Icon.Walk = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="13" cy="4" r="2"/>
    <path d="M10 22 l2-6 l3 2 l2 5 M8 11 l4-3 l4 4 l2 1"/>
  </svg>
);

Icon.Moon = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 14 a8 8 0 1 1 -10 -11 a6 6 0 0 0 10 11z"/>
  </svg>
);

Icon.Wind = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 8 h12 a3 3 0 1 0 -3 -3 M3 12 h17 a3 3 0 1 1 -3 3 M3 16 h11"/>
  </svg>
);

Icon.Clock = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <circle cx="12" cy="12" r="9"/>
    <path d="M12 7 V12 L15 14"/>
  </svg>
);

Icon.Apple = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 7 c-3 -3 -8 -1 -8 4 s4 11 8 11 s8 -6 8 -11 s-5 -7 -8 -4z"/>
    <path d="M12 7 c0 -2 1 -4 3 -5"/>
  </svg>
);

Icon.Salad = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 11 H21 a9 9 0 0 1 -18 0z"/>
    <path d="M7 11 c0 -2 2 -3 3 -2 M12 11 c0 -3 3 -4 5 -3 M15 11 c-1 -2 0 -4 2 -4"/>
  </svg>
);

Icon.Settings = ({ size = 18, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19 12 c0 .5 0 1 -.1 1.5 l2 1.5 -2 3 -2.5 -1 a7 7 0 0 1 -2.5 1.5 L13 21 H11 l-.4 -2.5 a7 7 0 0 1 -2.5 -1.5 l-2.5 1 -2 -3 2 -1.5 c-.1 -.5 -.1 -1 -.1 -1.5 s0 -1 .1 -1.5 l-2 -1.5 2 -3 2.5 1 a7 7 0 0 1 2.5 -1.5 L11 3 H13 l.4 2.5 a7 7 0 0 1 2.5 1.5 l2.5 -1 2 3 -2 1.5 c.1 .5 .1 1 .1 1.5z"/>
  </svg>
);

Icon.Flame = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 2 C 13 6 17 8 17 13 A 5 5 0 0 1 7 13 C 7 10 9 9 9 6 C 11 7 12 9 12 2 Z"/>
  </svg>
);

Icon.Trophy = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 4 H18 V9 a6 6 0 0 1 -12 0z"/>
    <path d="M6 6 H3 v2 a3 3 0 0 0 3 3 M18 6 h3 v2 a3 3 0 0 1 -3 3"/>
    <path d="M9 15 v3 h6 v-3 M8 21 h8"/>
  </svg>
);

Icon.Calendar = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <rect x="3" y="5" width="18" height="16" rx="2"/>
    <path d="M3 10 H21 M8 3 V7 M16 3 V7"/>
  </svg>
);

Icon.Chevron = ({ size = 14, color = 'currentColor', dir = 'right' }) => {
  const rot = { right: 0, left: 180, up: -90, down: 90 }[dir];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" style={{ transform: `rotate(${rot}deg)` }}>
      <path d="M9 6 L15 12 L9 18"/>
    </svg>
  );
};

Icon.Play = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M6 4 L20 12 L6 20 Z"/>
  </svg>
);

Icon.Drop = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <circle cx="12" cy="12" r="9"/>
  </svg>
);

Icon.Health = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 2 a3 3 0 0 1 3 3 c0 1 1 2 2 2 a3 3 0 0 1 0 6 c-1 0 -2 1 -2 2 a3 3 0 0 1 -6 0 c0 -1 -1 -2 -2 -2 a3 3 0 0 1 0 -6 c1 0 2 -1 2 -2 a3 3 0 0 1 3 -3z"/>
  </svg>
);

Icon.Lab = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 2 V9 L4 19 a2 2 0 0 0 2 3 H18 a2 2 0 0 0 2 -3 L15 9 V2"/>
    <path d="M7 2 H17 M6 14 H18"/>
  </svg>
);

Icon.Ruler = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinejoin="round">
    <rect x="2" y="9" width="20" height="6" rx="1"/>
    <path d="M6 9 V12 M9 9 V13 M12 9 V12 M15 9 V13 M18 9 V12"/>
  </svg>
);

Icon.Sync = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12 a9 9 0 0 1 -15 7 M3 12 a9 9 0 0 1 15 -7"/>
    <path d="M21 3 V9 H15 M3 21 V15 H9"/>
  </svg>
);

Icon.Notebook = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="3" width="16" height="18" rx="2"/>
    <path d="M8 3 V21 M11 8 H17 M11 12 H17 M11 16 H15"/>
  </svg>
);

Icon.Trash = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 7 H20 M10 7 V4 H14 V7 M6 7 L7 21 H17 L18 7 M10 11 V17 M14 11 V17"/>
  </svg>
);

Icon.Upload = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 4 V18 M6 10 L12 4 L18 10"/>
    <path d="M4 20 H20"/>
  </svg>
);

Icon.Camera = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9 a2 2 0 0 1 2 -2 H8 L10 5 H14 L16 7 H19 a2 2 0 0 1 2 2 V18 a2 2 0 0 1 -2 2 H5 a2 2 0 0 1 -2 -2 Z"/>
    <circle cx="12" cy="13" r="4"/>
  </svg>
);

window.Icon = Icon;
