// Profile screen
function ProfileScreen() {
  return (
    <div className="scroll">
      <div className="app-header">
        <div className="head-left">
          <span className="head-eyebrow">Tu perfil</span>
          <h1 style={{ fontSize: 36 }}>
            <span style={{ fontStyle: 'italic' }}>macy</span><span className="accent">.</span>
          </h1>
          <span className="head-date">programa · 12 semanas · sem 2</span>
        </div>
        <div style={{
          width: 56, height: 56, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--rose-glow), var(--bordeaux))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 24, color: 'white',
          boxShadow: '0 6px 16px rgba(194,40,107,0.4), inset 0 1px 0 rgba(255,255,255,0.35)',
        }}>M</div>
      </div>

      <div style={{ padding: '14px 18px 0' }}>
        <div className="card-dark" style={{ padding: 16 }}>
          <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--gold)', textTransform: 'uppercase' }}>
            Objetivo · 12 semanas
          </div>
          <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--lavender)', marginTop: 4, lineHeight: 1.15 }}>
            revertir resistencia<br/>a la insulina + hígado graso
          </div>
          <div style={{ marginTop: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.1em', color: 'var(--muted)', marginBottom: 6 }}>
              <span>SEMANA 2 / 12</span>
              <span style={{ color: 'var(--gold)' }}>17%</span>
            </div>
            <div className="progress"><div className="fill" style={{ width: '17%' }}/></div>
          </div>
        </div>
      </div>

      <div className="section-head"><span className="label">Configuración</span></div>
      <div className="pad" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {[
          { i: 'Bell', t: 'Notificaciones', s: '7 alarmas activas' },
          { i: 'Heart', t: 'Conexiones', s: 'Apple Health · iWatch' },
          { i: 'Trophy', t: 'Metas y rangos', s: 'peso, medidas, labs' },
          { i: 'Settings', t: 'Recordatorios', s: 'descansos, hidratación' },
          { i: 'User', t: 'Datos personales', s: 'edad, fc máx, alergias' },
        ].map((r, i) => {
          const Cmp = Icon[r.i] || Icon.Settings;
          return (
            <button key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 14px', borderRadius: 14, textAlign: 'left',
              background: 'rgba(247,217,252,0.04)',
              border: '1px solid var(--hairline-2)',
            }}>
              <div style={{
                width: 34, height: 34, borderRadius: 10,
                background: 'rgba(247,217,252,0.08)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--gold)',
              }}><Cmp size={16}/></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 500 }}>{r.t}</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.05em', marginTop: 2 }}>{r.s}</div>
              </div>
              <Icon.Chevron size={14} color="rgba(247,217,252,0.4)"/>
            </button>
          );
        })}
      </div>

      <div style={{ padding: '24px 18px 0' }}>
        <div style={{ textAlign: 'center', fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.16em', color: 'var(--muted)', textTransform: 'uppercase' }}>
          ✦ app hábitos · v0.9 · y2k ✦
        </div>
      </div>
    </div>
  );
}

window.ProfileScreen = ProfileScreen;
