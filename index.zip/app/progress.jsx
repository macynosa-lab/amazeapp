// Progress screen
function ProgressScreen() {
  const [view, setView] = useState('week');
  const p = DATA.progress;

  return (
    <div className="scroll">
      <div className="app-header">
        <div className="head-left">
          <span className="head-eyebrow">Tu progreso</span>
          <h1 style={{ fontSize: 36 }}>
            <span className="accent">−2.3</span><span style={{ fontStyle: 'italic' }}>kg</span><br/>
            <span style={{ fontSize: 22, fontStyle: 'italic', color: 'var(--muted)' }}>en 6 semanas</span>
          </h1>
        </div>
        <Icon.Sparkle size={26} color="#FAB940"/>
      </div>

      <div className="pad" style={{ marginTop: 10 }}>
        <div className="segmented">
          {['week', 'month', 'year'].map(v => (
            <button key={v}
              className={view === v ? 'active' : ''}
              onClick={() => setView(v)}>
              {v === 'week' ? 'semana' : v === 'month' ? 'mes' : 'año'}
            </button>
          ))}
        </div>
      </div>

      {/* HERO STATS */}
      <div style={{ padding: '16px 18px 0' }}>
        <div className="card-rose" style={{ padding: 18 }}>
          <SparkleAccent/>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.85 }}>
                Semana {DATA.today.week} en curso
              </div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 44, lineHeight: 0.95, marginTop: 6 }}>
                {Math.round(p.weekly.supps * 100)}<span style={{ fontSize: 18 }}>%</span>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.12em', opacity: 0.85, marginTop: 2 }}>
                ADHERENCIA TOTAL
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <Icon.Flame size={26} color="#FAB940"/>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 28, marginTop: 4, color: 'var(--gold)' }}>
                {p.weekly.streak}d
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.12em', opacity: 0.8 }}>
                RACHA
              </div>
            </div>
          </div>
          <div className="hairline" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)', margin: '14px 0' }}/>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            {[
              { k: 'Entrenos', v: `${p.weekly.workouts}/${p.weekly.workoutsGoal}` },
              { k: 'Suplem.', v: `${Math.round(p.weekly.supps * 100)}%` },
              { k: 'Anclas', v: `${Math.round(p.weekly.anchors * 100)}%` },
            ].map((x, i) => (
              <div key={i}>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.14em', opacity: 0.75, textTransform: 'uppercase' }}>
                  {x.k}
                </div>
                <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 22, marginTop: 2 }}>
                  {x.v}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* WEIGHT CHART */}
      <div className="section-head">
        <span className="label">Peso · 6 semanas</span>
        <span className="more">↓ 2.3 kg</span>
      </div>
      <div className="pad">
        <div className="chart-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 32, color: 'var(--lavender)', lineHeight: 1 }}>
                70.1 <span style={{ fontSize: 14, opacity: 0.6 }}>kg</span>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.12em', marginTop: 2 }}>
                META · 65 KG · −5.1 KG
              </div>
            </div>
            <span className="pill gold">
              <Icon.Chevron size={10} dir="down"/> 3.2%
            </span>
          </div>
          <Sparkline data={p.weight} color="#FAB940" width={300} height={70}/>
        </div>
      </div>

      {/* WEEK ADHERENCE */}
      <div className="section-head">
        <span className="label">Suplementos · semana</span>
      </div>
      <div className="pad">
        <div className="chart-card">
          <BarChart
            data={[
              { d: 'L', v: 7 }, { d: 'M', v: 2 }, { d: 'X', v: 0 },
              { d: 'J', v: 0 }, { d: 'V', v: 0 }, { d: 'S', v: 0 }, { d: 'D', v: 0 },
            ]}
            width={300} height={100} color="#E94F8B"
          />
        </div>
      </div>

      {/* ACHIEVEMENTS */}
      <div className="section-head">
        <span className="label">Logros recientes</span>
        <span className="more">3</span>
      </div>
      <div className="pad" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {p.monthlyAchievements.map((a, i) => {
          const Cmp = Icon[a.icon] || Icon.Trophy;
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 14px', borderRadius: 16,
              background: 'rgba(247,217,252,0.04)',
              border: '1px solid var(--hairline-2)',
            }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12,
                background: 'linear-gradient(135deg, var(--gold), var(--gold-deep))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--ink)', flexShrink: 0,
                boxShadow: '0 4px 12px rgba(250,185,64,0.35), inset 0 1px 0 rgba(255,255,255,0.5)',
              }}>
                <Cmp size={20}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 500 }}>{a.title}</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.06em', marginTop: 2 }}>
                  {a.sub}
                </div>
              </div>
              <Icon.Sparkle size={14} color="#FAB940"/>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.ProgressScreen = ProgressScreen;
