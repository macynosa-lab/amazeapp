// Health / Body screen — InBody + Labs + Medidas with import & comparative history
function HealthScreen() {
  const { state, actions } = useApp();
  const [tab, setTab] = useState('inbody');
  const [importSheet, setImportSheet] = useState(null); // 'inbody' | 'labs' | 'measures'

  const lastInbody = state.inbodyHistory[state.inbodyHistory.length - 1];
  const prevInbody = state.inbodyHistory[state.inbodyHistory.length - 2];
  const firstInbody = state.inbodyHistory[0];

  const currentWeight = lastInbody?.weight ?? DATA.body.weight.current;
  const startWeight = firstInbody?.weight ?? DATA.body.weight.prev;
  const delta = (currentWeight - startWeight).toFixed(1);
  const goalWeight = state.profile.goalWeight || 65;
  const goalPct = Math.max(0, Math.min(1, (startWeight - currentWeight) / Math.max(0.1, startWeight - goalWeight)));

  return (
    <>
      <div className="scroll">
        <div className="app-header">
          <div className="head-left">
            <span className="head-eyebrow">Salud · cuerpo & labs</span>
            <h1 style={{ fontSize: 36 }}>
              tu <span className="accent">cuerpo</span><br/>
              <span style={{ fontStyle: 'italic' }}>en datos</span>
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" onClick={() => exportHealthReport(state)} title="Exportar PDF">
              <Icon.Download size={16}/>
            </button>
            <button className="icon-btn" onClick={() => setImportSheet(tab)} title="Agregar">
              <Icon.Plus size={16}/>
            </button>
          </div>
        </div>

        {/* WEIGHT TILE */}
        <div style={{ padding: '14px 18px 0' }}>
          <div className="card-gold" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', padding: 18 }}>
            <div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.7 }}>
                Peso actual
              </div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 56, lineHeight: 0.95, marginTop: 4, color: 'var(--ink)' }}>
                {currentWeight}<span style={{ fontSize: 22, opacity: 0.6 }}>kg</span>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 11, letterSpacing: '0.1em', color: 'var(--ink)', opacity: 0.7, marginTop: 4 }}>
                {delta < 0 ? '↓' : '↑'} {Math.abs(delta)} KG · {state.inbodyHistory.length} REGISTROS
              </div>
            </div>
            <div style={{ position: 'relative', width: 80, height: 80 }}>
              <svg viewBox="0 0 80 80" width="80" height="80">
                <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(91,28,46,0.2)" strokeWidth="6"/>
                <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(91,28,46,0.95)" strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 34}
                  strokeDashoffset={2 * Math.PI * 34 * (1 - goalPct)}
                  transform="rotate(-90 40 40)"
                />
              </svg>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', color: 'var(--ink)' }}>
                <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 18, lineHeight: 1 }}>{Math.round(goalPct * 100)}%</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 7.5, letterSpacing: '0.15em', opacity: 0.75 }}>META</div>
              </div>
            </div>
          </div>
        </div>

        {/* TABS */}
        <div className="pad" style={{ marginTop: 16 }}>
          <div className="segmented">
            {[
              { v: 'inbody', l: 'inbody' },
              { v: 'medidas', l: 'medidas' },
              { v: 'labs', l: 'labs' },
            ].map(t => (
              <button key={t.v} className={tab === t.v ? 'active' : ''} onClick={() => setTab(t.v)}>
                {t.l}
              </button>
            ))}
          </div>
        </div>

        {tab === 'inbody'  && <InbodyTab history={state.inbodyHistory} onImport={() => setImportSheet('inbody')}/>}
        {tab === 'medidas' && <MeasuresTab history={state.measuresHistory} onImport={() => setImportSheet('measures')}/>}
        {tab === 'labs'    && <LabsTab history={state.labsHistory} onImport={() => setImportSheet('labs')}/>}

        <div style={{ height: 12 }}/>
      </div>

      {importSheet === 'inbody'   && <ImportInbodySheet onClose={() => setImportSheet(null)}/>}
      {importSheet === 'measures' && <ImportMeasuresSheet onClose={() => setImportSheet(null)}/>}
      {importSheet === 'labs'     && <ImportLabsSheet onClose={() => setImportSheet(null)}/>}
    </>
  );
}

// ─── InBody tab ───
const INBODY_METRICS = [
  { key: 'weight',   label: 'Peso',           unit: 'kg', good: 'down', color: '#F7D9FC' },
  { key: 'fat',      label: 'Grasa',          unit: '%',  good: 'down', color: '#E94F8B' },
  { key: 'muscle',   label: 'Músculo',        unit: 'kg', good: 'up',   color: '#7BE2A8' },
  { key: 'water',    label: 'Agua',           unit: '%',  good: 'up',   color: '#85B4FF' },
  { key: 'visceral', label: 'Visceral',       unit: 'lvl', good: 'down', color: '#FAB940' },
  { key: 'bmr',      label: 'BMR',            unit: 'kcal', good: 'up',  color: '#C2A8F0' },
];

function InbodyTab({ history, onImport }) {
  const [focus, setFocus] = useState('fat');
  const last = history[history.length - 1] || {};
  const prev = history[history.length - 2] || last;

  return (
    <>
      <div className="pad" style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {INBODY_METRICS.map(m => {
          const v  = last[m.key];
          const pv = prev[m.key];
          if (v === undefined) return null;
          const delta = +(v - pv).toFixed(1);
          const good = (m.good === 'up' && delta > 0) || (m.good === 'down' && delta < 0) || delta === 0;
          return (
            <button key={m.key} onClick={() => setFocus(m.key)}
              style={{
                padding: 14,
                background: focus === m.key
                  ? 'linear-gradient(180deg, rgba(250,185,64,0.18), rgba(250,185,64,0.02))'
                  : 'linear-gradient(180deg, rgba(247,217,252,0.08), rgba(247,217,252,0.02))',
                border: '1px solid ' + (focus === m.key ? 'rgba(250,185,64,0.5)' : 'var(--hairline)'),
                borderRadius: 20,
                textAlign: 'left',
                position: 'relative',
                color: 'var(--lavender)',
              }}>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase' }}>
                {m.label}
              </div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 26, color: 'var(--lavender)', lineHeight: 1, marginTop: 4 }}>
                {v}<span style={{ fontSize: 11, opacity: 0.6 }}>{m.unit}</span>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, marginTop: 4,
                color: delta === 0 ? 'var(--muted)' : good ? '#7BE2A8' : 'var(--rose-glow)',
                letterSpacing: '0.06em' }}>
                {delta === 0 ? '— sin cambio' : (delta > 0 ? '↑ +' : '↓ ') + Math.abs(delta) + ' vs ant.'}
              </div>
            </button>
          );
        })}
      </div>

      {/* Comparative history chart */}
      <div className="section-head">
        <span className="label">Historial · {INBODY_METRICS.find(m => m.key === focus)?.label}</span>
        <span className="more">{history.length} ingr.</span>
      </div>
      <div className="pad">
        <div className="chart-card">
          <MetricHistoryChart
            data={history.map(h => ({ d: h.label.split(' ')[0] + ' ' + h.label.split(' ')[1], v: h[focus] }))}
            unit={INBODY_METRICS.find(m => m.key === focus)?.unit}
            color={INBODY_METRICS.find(m => m.key === focus)?.color}
          />
        </div>
      </div>

      {/* History table */}
      <div className="section-head">
        <span className="label">Registros</span>
      </div>
      <div className="pad">
        <div className="card-dark" style={{ padding: '6px 14px' }}>
          {history.slice().reverse().map((h, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 0',
              borderBottom: i < history.length - 1 ? '1px solid var(--hairline-2)' : 'none',
            }}>
              <div>
                <div style={{ fontSize: 13, color: 'var(--lavender)', fontWeight: 500 }}>{h.label}</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--muted)', letterSpacing: '0.08em', marginTop: 2 }}>
                  {h.weight} KG · {h.fat}% GR · {h.muscle} KG MM
                </div>
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--gold)', letterSpacing: '0.1em' }}>
                #{history.length - i}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '14px 18px 0' }}>
        <button className="btn ghost btn-block" onClick={onImport}>
          <Icon.Upload size={14}/> Importar / agregar InBody
        </button>
      </div>
    </>
  );
}

// ─── Measures tab ───
const MEASURES_KEYS = [
  { key: 'waist', label: 'Cintura' },
  { key: 'hip',   label: 'Cadera' },
  { key: 'thigh', label: 'Muslo' },
  { key: 'arm',   label: 'Brazo' },
  { key: 'chest', label: 'Pecho' },
];

function MeasuresTab({ history, onImport }) {
  const [focus, setFocus] = useState('waist');
  const last = history[history.length - 1] || {};
  const first = history[0] || last;

  return (
    <>
      <div className="pad" style={{ marginTop: 14 }}>
        <div className="card-dark" style={{ padding: '6px 14px' }}>
          {MEASURES_KEYS.map((m, i) => {
            const v = last[m.key];
            const fv = first[m.key];
            const delta = +(v - fv).toFixed(1);
            const good = delta < 0;
            return (
              <button key={m.key} onClick={() => setFocus(m.key)}
                style={{
                  width: '100%',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '14px 0',
                  borderBottom: i < MEASURES_KEYS.length - 1 ? '1px solid var(--hairline-2)' : 'none',
                  textAlign: 'left',
                  background: focus === m.key ? 'rgba(250,185,64,0.06)' : 'transparent',
                  margin: '0 -14px',
                  paddingLeft: 14, paddingRight: 14,
                }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{
                    width: 30, height: 30, borderRadius: 10,
                    background: focus === m.key ? 'rgba(250,185,64,0.18)' : 'rgba(247,217,252,0.08)',
                    color: focus === m.key ? 'var(--gold)' : 'var(--lavender)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Icon.Ruler size={14}/>
                  </div>
                  <div>
                    <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 500 }}>{m.label}</div>
                    <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.05em', marginTop: 2 }}>
                      inicio · {fv} cm
                    </div>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--lavender)', lineHeight: 1 }}>
                    {v}<span style={{ fontSize: 11, opacity: 0.6 }}>cm</span>
                  </div>
                  <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.08em', color: delta === 0 ? 'var(--muted)' : good ? '#7BE2A8' : 'var(--rose-glow)', marginTop: 2 }}>
                    {delta === 0 ? '—' : (delta > 0 ? '↑ +' : '↓ ') + Math.abs(delta)}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="section-head">
        <span className="label">Historial · {MEASURES_KEYS.find(m => m.key === focus)?.label}</span>
        <span className="more">{history.length} ingr.</span>
      </div>
      <div className="pad">
        <div className="chart-card">
          <MetricHistoryChart
            data={history.map(h => ({ d: h.label, v: h[focus] }))}
            unit="cm"
            color="#E94F8B"
          />
        </div>
      </div>

      <div style={{ padding: '14px 18px 0' }}>
        <button className="btn ghost btn-block" onClick={onImport}>
          <Icon.Upload size={14}/> Importar / agregar medidas
        </button>
      </div>
    </>
  );
}

// ─── Labs tab ───
const LABS_KEYS = [
  { key: 'glucose',  label: 'Glucosa ayunas', unit: 'mg/dL', range: '70–99',  good: 'down' },
  { key: 'homa',     label: 'HOMA-IR',        unit: '',      range: '<2.5',   good: 'down' },
  { key: 'trig',     label: 'Triglicéridos',  unit: 'mg/dL', range: '<150',   good: 'down' },
  { key: 'alt',      label: 'ALT (hígado)',   unit: 'U/L',   range: '7–35',   good: 'down' },
  { key: 'ast',      label: 'AST (hígado)',   unit: 'U/L',   range: '8–33',   good: 'down' },
  { key: 'vitD',     label: 'Vitamina D',     unit: 'ng/mL', range: '30–80',  good: 'up' },
  { key: 'iron',     label: 'Hierro sérico',  unit: 'µg/dL', range: '60–170', good: 'up' },
  { key: 'ferritin', label: 'Ferritina',      unit: 'ng/mL', range: '15–150', good: 'up' },
];

function statusFor(key, value) {
  if (key === 'glucose')  return value <= 99  ? 'optimal' : value <= 125 ? 'watch' : 'high';
  if (key === 'homa')     return value < 2.5  ? 'optimal' : value < 4    ? 'watch' : 'high';
  if (key === 'trig')     return value < 150  ? 'optimal' : value < 200  ? 'watch' : 'high';
  if (key === 'alt')      return value <= 35  ? 'optimal' : 'high';
  if (key === 'ast')      return value <= 33  ? 'optimal' : 'high';
  if (key === 'vitD')     return value >= 30  ? 'optimal' : value >= 20  ? 'low'   : 'low';
  if (key === 'iron')     return value >= 60  ? 'optimal' : 'low';
  if (key === 'ferritin') return value >= 15  ? (value < 30 ? 'watch' : 'optimal') : 'low';
  return 'optimal';
}

function LabsTab({ history, onImport }) {
  const [focus, setFocus] = useState('glucose');
  const last = history[history.length - 1] || {};
  const prev = history[history.length - 2] || last;

  return (
    <>
      <div className="pad" style={{ marginTop: 14 }}>
        <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 8 }}>
          Estudio · {last.label} · vs {prev.label}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {LABS_KEYS.map(l => {
            const v = last[l.key];
            const pv = prev[l.key];
            if (v === undefined) return null;
            const status = statusFor(l.key, v);
            const delta = +(v - pv).toFixed(1);
            return (
              <button key={l.key} onClick={() => setFocus(l.key)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '12px 14px', borderRadius: 14,
                background: focus === l.key ? 'rgba(250,185,64,0.08)' : 'rgba(247,217,252,0.04)',
                border: '1px solid ' + (focus === l.key ? 'rgba(250,185,64,0.4)' : 'var(--hairline-2)'),
                textAlign: 'left',
                width: '100%',
              }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, color: 'var(--lavender)', fontWeight: 500 }}>{l.label}</div>
                  <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--muted)', letterSpacing: '0.06em', marginTop: 2 }}>
                    RANGO {l.range}{l.unit && ` ${l.unit}`} · ANT {pv}{delta !== 0 ? ` (${delta > 0 ? '+' : ''}${delta})` : ''}
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 20, color: 'var(--lavender)', lineHeight: 1 }}>
                    {v}<span style={{ fontSize: 9.5, opacity: 0.6, marginLeft: 2 }}>{l.unit}</span>
                  </div>
                  <span className={'lab-badge ' + status} style={{ marginTop: 4 }}>
                    {status === 'optimal' ? 'óptimo' : status === 'watch' ? 'observar' : status === 'low' ? 'bajo' : 'alto'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="section-head">
        <span className="label">Historial · {LABS_KEYS.find(l => l.key === focus)?.label}</span>
        <span className="more">{history.length} ingr.</span>
      </div>
      <div className="pad">
        <div className="chart-card">
          <MetricHistoryChart
            data={history.map(h => ({ d: h.label, v: h[focus] }))}
            unit={LABS_KEYS.find(l => l.key === focus)?.unit}
            color="#FAB940"
          />
          <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--hairline-2)' }}>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 6 }}>
              Resumen
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--lavender)', lineHeight: 1.4 }}>
              {labsSummary(focus, history)}
            </div>
          </div>
        </div>
      </div>

      <div style={{ padding: '14px 18px 0' }}>
        <button className="btn ghost btn-block" onClick={onImport}>
          <Icon.Upload size={14}/> Importar / agregar laboratorios
        </button>
      </div>
    </>
  );
}

function labsSummary(key, history) {
  if (history.length < 2) return 'Aún no hay comparativa. Agrega otro estudio para ver tu evolución.';
  const first = history[0][key];
  const last  = history[history.length - 1][key];
  const delta = +(last - first).toFixed(1);
  const label = LABS_KEYS.find(l => l.key === key)?.label;
  if (delta === 0) return `${label} sin cambios desde tu primer estudio.`;
  const arrow = delta > 0 ? '↑' : '↓';
  const meta = LABS_KEYS.find(l => l.key === key);
  const isGood = (meta.good === 'down' && delta < 0) || (meta.good === 'up' && delta > 0);
  return `${arrow} ${Math.abs(delta)} ${meta.unit} desde ${history[0].label}. ${isGood ? '✓ va en la dirección correcta.' : '⚠ revisa con tu médico.'}`;
}

// ─── Metric history chart with comparison ───
function MetricHistoryChart({ data, unit, color = '#FAB940' }) {
  const width = 300, height = 110;
  if (!data.length) {
    return <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 11, color: 'var(--muted)', padding: 20, textAlign: 'center' }}>Sin datos aún</div>;
  }
  const vals = data.map(d => d.v);
  const max = Math.max(...vals);
  const min = Math.min(...vals);
  const range = max - min || 1;
  const pad = range * 0.15;
  const yMax = max + pad, yMin = min - pad;
  const yRange = yMax - yMin;

  const pts = data.map((d, i) => {
    const x = data.length === 1 ? width / 2 : (i / (data.length - 1)) * (width - 20) + 10;
    const y = height - ((d.v - yMin) / yRange) * (height - 20) - 10;
    return [x, y, d];
  });

  const pathLine = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0] + ' ' + p[1]).join(' ');
  const pathArea = pathLine + ` L ${pts[pts.length-1][0]} ${height} L ${pts[0][0]} ${height} Z`;
  const last = data[data.length - 1];
  const first = data[0];
  const totalDelta = +(last.v - first.v).toFixed(1);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
        <div>
          <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 28, color: 'var(--lavender)', lineHeight: 1 }}>
            {last.v}<span style={{ fontSize: 13, opacity: 0.6, marginLeft: 2 }}>{unit}</span>
          </div>
          <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.1em', color: 'var(--muted)', marginTop: 2 }}>
            {first.d} · {first.v}{unit} → HOY
          </div>
        </div>
        {data.length > 1 && (
          <span className="pill" style={{
            background: totalDelta < 0 ? 'rgba(123,226,168,0.14)' : 'rgba(233,79,139,0.14)',
            color: totalDelta < 0 ? '#7BE2A8' : 'var(--rose-glow)',
            borderColor: totalDelta < 0 ? 'rgba(123,226,168,0.3)' : 'rgba(233,79,139,0.3)',
          }}>
            {totalDelta > 0 ? '↑' : '↓'} {Math.abs(totalDelta)} {unit}
          </span>
        )}
      </div>
      <svg width={width} height={height + 28} viewBox={`0 0 ${width} ${height + 28}`} style={{ overflow: 'visible', width: '100%' }}>
        <defs>
          <linearGradient id={`area-${color}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.4"/>
            <stop offset="100%" stopColor={color} stopOpacity="0"/>
          </linearGradient>
        </defs>
        {pts.length > 1 && <path d={pathArea} fill={`url(#area-${color})`}/>}
        {pts.length > 1 && <path d={pathLine} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>}
        {pts.map((p, i) => (
          <g key={i}>
            <circle cx={p[0]} cy={p[1]} r={i === pts.length - 1 ? 5 : 3} fill={color}/>
            {i === pts.length - 1 && <circle cx={p[0]} cy={p[1]} r={10} fill={color} opacity="0.2"/>}
            <text x={p[0]} y={p[1] - 10} fill="var(--lavender)"
                  fontFamily="DM Serif Display, serif" fontStyle="italic" fontSize="11" textAnchor="middle" opacity="0.85">
              {p[2].v}
            </text>
            <text x={p[0]} y={height + 16} fill="rgba(247,217,252,0.5)"
                  fontFamily="Space Mono, monospace" fontSize="9" textAnchor="middle">
              {p[2].d}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

// ─── Import sheets ───
function ImportInbodySheet({ onClose }) {
  const { state, actions } = useApp();
  const last = state.inbodyHistory[state.inbodyHistory.length - 1] || {};
  const [form, setForm] = useState({
    date: todayISO(),
    weight: last.weight || 70,
    fat: last.fat || 28,
    muscle: last.muscle || 27,
    water: last.water || 52,
    visceral: last.visceral || 7,
    bmr: last.bmr || 1400,
  });

  const save = () => {
    actions.addInbody({
      date: form.date,
      label: prettyLabel(form.date),
      weight: +form.weight,
      fat: +form.fat,
      muscle: +form.muscle,
      water: +form.water,
      visceral: +form.visceral,
      bmr: +form.bmr,
    });
    onClose();
  };

  return (
    <Sheet open={true} onClose={onClose} title="Importar InBody">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        captura tu reporte de InBody
      </div>
      <div className="hairline"/>

      <OcrCapture
        kind="inbody"
        onExtracted={(data) => setForm(f => ({ ...f, ...data }))}
      />

      <FormField label="Fecha del estudio">
        <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}
          style={{ colorScheme: 'dark', color: 'var(--gold)' }}/>
      </FormField>
      <FormField label="Peso · kg">
        <input type="number" step="0.1" value={form.weight} onChange={e => setForm({ ...form, weight: e.target.value })}/>
      </FormField>
      <FormField label="Grasa · %">
        <input type="number" step="0.1" value={form.fat} onChange={e => setForm({ ...form, fat: e.target.value })}/>
      </FormField>
      <FormField label="Músculo · kg">
        <input type="number" step="0.1" value={form.muscle} onChange={e => setForm({ ...form, muscle: e.target.value })}/>
      </FormField>
      <FormField label="Agua · %">
        <input type="number" step="0.1" value={form.water} onChange={e => setForm({ ...form, water: e.target.value })}/>
      </FormField>
      <FormField label="Grasa visceral · lvl">
        <input type="number" step="1" value={form.visceral} onChange={e => setForm({ ...form, visceral: e.target.value })}/>
      </FormField>
      <FormField label="BMR · kcal">
        <input type="number" step="10" value={form.bmr} onChange={e => setForm({ ...form, bmr: e.target.value })}/>
      </FormField>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={save}>
        <Icon.Check size={14}/> Guardar registro
      </button>
    </Sheet>
  );
}

function ImportMeasuresSheet({ onClose }) {
  const { state, actions } = useApp();
  const last = state.measuresHistory[state.measuresHistory.length - 1] || {};
  const [form, setForm] = useState({
    date: todayISO(),
    waist: last.waist || 78, hip: last.hip || 102, thigh: last.thigh || 58, arm: last.arm || 28, chest: last.chest || 92,
  });

  const save = () => {
    actions.addMeasures({
      date: form.date,
      label: prettyLabelShort(form.date),
      waist: +form.waist, hip: +form.hip, thigh: +form.thigh, arm: +form.arm, chest: +form.chest,
    });
    onClose();
  };

  return (
    <Sheet open={true} onClose={onClose} title="Nuevas medidas">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        cinta métrica · cm
      </div>
      <div className="hairline"/>
      <OcrCapture
        kind="measures"
        onExtracted={(data) => setForm(f => ({ ...f, ...data }))}
      />
      <FormField label="Fecha">
        <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}
          style={{ colorScheme: 'dark', color: 'var(--gold)' }}/>
      </FormField>
      <FormField label="Cintura"><input type="number" step="0.5" value={form.waist} onChange={e => setForm({ ...form, waist: e.target.value })}/></FormField>
      <FormField label="Cadera"><input type="number" step="0.5" value={form.hip} onChange={e => setForm({ ...form, hip: e.target.value })}/></FormField>
      <FormField label="Muslo"><input type="number" step="0.5" value={form.thigh} onChange={e => setForm({ ...form, thigh: e.target.value })}/></FormField>
      <FormField label="Brazo"><input type="number" step="0.5" value={form.arm} onChange={e => setForm({ ...form, arm: e.target.value })}/></FormField>
      <FormField label="Pecho"><input type="number" step="0.5" value={form.chest} onChange={e => setForm({ ...form, chest: e.target.value })}/></FormField>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={save}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

function ImportLabsSheet({ onClose }) {
  const { state, actions } = useApp();
  const last = state.labsHistory[state.labsHistory.length - 1] || {};
  const [form, setForm] = useState({
    date: todayISO(),
    glucose: last.glucose || 90, homa: last.homa || 2.0, trig: last.trig || 130,
    alt: last.alt || 28, ast: last.ast || 24,
    vitD: last.vitD || 22, iron: last.iron || 65, ferritin: last.ferritin || 18,
  });

  const save = () => {
    actions.addLabs({
      date: form.date,
      label: prettyLabelShort(form.date),
      glucose: +form.glucose, homa: +form.homa, trig: +form.trig,
      alt: +form.alt, ast: +form.ast,
      vitD: +form.vitD, iron: +form.iron, ferritin: +form.ferritin,
    });
    onClose();
  };

  return (
    <Sheet open={true} onClose={onClose} title="Importar laboratorios">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        captura tu estudio bioquímico
      </div>
      <div className="hairline"/>

      <OcrCapture
        kind="labs"
        onExtracted={(data) => setForm(f => ({ ...f, ...data }))}
      />

      <FormField label="Fecha del estudio">
        <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}
          style={{ colorScheme: 'dark', color: 'var(--gold)' }}/>
      </FormField>
      <FormField label="Glucosa · mg/dL"><input type="number" step="1" value={form.glucose} onChange={e => setForm({ ...form, glucose: e.target.value })}/></FormField>
      <FormField label="HOMA-IR"><input type="number" step="0.1" value={form.homa} onChange={e => setForm({ ...form, homa: e.target.value })}/></FormField>
      <FormField label="Triglicéridos · mg/dL"><input type="number" step="1" value={form.trig} onChange={e => setForm({ ...form, trig: e.target.value })}/></FormField>
      <FormField label="ALT · U/L"><input type="number" step="1" value={form.alt} onChange={e => setForm({ ...form, alt: e.target.value })}/></FormField>
      <FormField label="AST · U/L"><input type="number" step="1" value={form.ast} onChange={e => setForm({ ...form, ast: e.target.value })}/></FormField>
      <FormField label="Vit D · ng/mL"><input type="number" step="1" value={form.vitD} onChange={e => setForm({ ...form, vitD: e.target.value })}/></FormField>
      <FormField label="Hierro · µg/dL"><input type="number" step="1" value={form.iron} onChange={e => setForm({ ...form, iron: e.target.value })}/></FormField>
      <FormField label="Ferritina · ng/mL"><input type="number" step="1" value={form.ferritin} onChange={e => setForm({ ...form, ferritin: e.target.value })}/></FormField>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={save}>
        <Icon.Check size={14}/> Guardar laboratorios
      </button>
    </Sheet>
  );
}

// ─── helpers ───
function todayISO() {
  const d = new Date(2026, 4, 12);
  return d.toISOString().slice(0, 10);
}
function prettyLabel(iso) {
  const months = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  const d = new Date(iso);
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}
function prettyLabelShort(iso) {
  const months = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const d = new Date(iso);
  return `${months[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
}

window.HealthScreen = HealthScreen;
