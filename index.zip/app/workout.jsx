// Workout screen
function WorkoutScreen() {
  const wk = DATA.today.workout;
  const [activeIdx, setActiveIdx] = useState(0);
  const [sets, setSets] = useState(() => wk.exercises.map(ex => {
    const n = ex.sets || 3;
    return Array.from({ length: n }, (_, i) => ({ reps: '', kg: '', done: false }));
  }));
  const [timer, setTimer] = useState({ running: false, secs: 0 });
  const [restOpen, setRestOpen] = useState(false);
  const [restLeft, setRestLeft] = useState(90);

  useEffect(() => {
    if (!timer.running) return;
    const id = setInterval(() => setTimer(t => ({ ...t, secs: t.secs + 1 })), 1000);
    return () => clearInterval(id);
  }, [timer.running]);

  useEffect(() => {
    if (!restOpen) return;
    const id = setInterval(() => setRestLeft(r => Math.max(0, r - 1)), 1000);
    return () => clearInterval(id);
  }, [restOpen]);

  const toggleSet = (exI, setI) => {
    setSets(s => s.map((arr, i) => i !== exI ? arr : arr.map((x, j) => j !== setI ? x : { ...x, done: !x.done })));
    if (!sets[exI][setI].done) {
      setRestOpen(true);
      setRestLeft(90);
    }
  };
  const updSet = (exI, setI, key, val) => {
    setSets(s => s.map((arr, i) => i !== exI ? arr : arr.map((x, j) => j !== setI ? x : { ...x, [key]: val })));
  };

  const mm = String(Math.floor(timer.secs / 60)).padStart(2, '0');
  const ss = String(timer.secs % 60).padStart(2, '0');

  const ex = wk.exercises[activeIdx];
  const doneCount = sets.reduce((a, b) => a + b.filter(x => x.done).length, 0);
  const totalCount = sets.reduce((a, b) => a + b.length, 0);

  return (
    <>
      <div className="scroll">
        <div className="app-header">
          <div className="head-left">
            <span className="head-eyebrow">Entreno · semana 2 · día 9</span>
            <h1 style={{ fontSize: 32 }}>
              <span className="accent">cardio</span><br/>
              <span style={{ fontStyle: 'italic' }}>zona 2</span>
            </h1>
            <span className="head-date">45 min · rpe 5–6 · 114–125 lpm</span>
          </div>
          <button className="icon-btn">
            <Icon.Settings size={16}/>
          </button>
        </div>

        {/* TIMER CARD */}
        <div style={{ padding: '16px 18px 0' }}>
          <div className="card-dark" style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '14px 16px',
            background: 'linear-gradient(135deg, rgba(250,185,64,0.12), rgba(233,79,139,0.08))',
            borderColor: 'rgba(250,185,64,0.3)',
          }}>
            <div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--gold)', textTransform: 'uppercase' }}>
                Tiempo de sesión
              </div>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 38, lineHeight: 1, color: 'var(--lavender)', marginTop: 2 }}>
                {mm}:{ss}
              </div>
            </div>
            <button
              className={'btn ' + (timer.running ? 'ghost' : 'gold')}
              style={{ height: 44, width: 44, padding: 0, borderRadius: '50%' }}
              onClick={() => setTimer(t => ({ ...t, running: !t.running }))}
            >
              {timer.running ? <Icon.Pause size={16}/> : <Icon.Play size={14}/>}
            </button>
          </div>
        </div>

        {/* EXERCISE TABS */}
        <div className="section-head">
          <span className="label">Ejercicios</span>
          <span className="more">{doneCount}/{totalCount} sets</span>
        </div>
        <div style={{ padding: '0 18px 0', display: 'flex', gap: 8, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {wk.exercises.map((e, i) => {
            const allDone = sets[i].every(x => x.done);
            return (
              <button key={i}
                onClick={() => setActiveIdx(i)}
                style={{
                  flexShrink: 0,
                  padding: '10px 14px', borderRadius: 14,
                  background: activeIdx === i
                    ? 'linear-gradient(180deg, var(--rose-glow), var(--rose))'
                    : 'rgba(247,217,252,0.04)',
                  border: '1px solid ' + (activeIdx === i ? 'var(--rose-glow)' : 'var(--hairline-2)'),
                  textAlign: 'left',
                  color: 'var(--lavender)',
                  boxShadow: activeIdx === i ? '0 4px 14px rgba(194,40,107,0.45)' : 'none',
                }}>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 8.5, letterSpacing: '0.14em', textTransform: 'uppercase', opacity: 0.7 }}>
                  {String(i + 1).padStart(2, '0')} · {allDone ? '✓ HECHO' : e.kind}
                </div>
                <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 15, marginTop: 2, lineHeight: 1.1 }}>
                  {e.name}
                </div>
              </button>
            );
          })}
        </div>

        {/* ACTIVE EXERCISE CARD */}
        <div style={{ padding: '14px 18px 0' }}>
          <div className="card" style={{ padding: 18 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
              <span className="pill rose" style={{ background: 'rgba(194,40,107,0.18)', color: 'var(--rose)', borderColor: 'rgba(194,40,107,0.4)' }}>
                <Icon.Dumbbell size={10}/> {ex.kind}
              </span>
              <span style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--ink-2)', letterSpacing: '0.1em' }}>
                {ex.sets} × {ex.reps || ex.target}
              </span>
            </div>
            <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 26, lineHeight: 1, marginTop: 8 }}>
              {ex.name}
            </div>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 11, color: 'var(--ink-2)', marginTop: 6, letterSpacing: '0.04em' }}>
              {ex.detail} {ex.tool && '· ' + ex.tool}
            </div>

            <div style={{ height: 1, background: 'rgba(91,28,46,0.15)', margin: '14px 0 10px' }}/>

            {/* sets */}
            <div className="set-row" style={{ borderBottom: '1px solid rgba(91,28,46,0.15)', padding: '4px 0 8px' }}>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, color: 'var(--ink-2)', letterSpacing: '0.12em', textAlign: 'center' }}>SET</div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, color: 'var(--ink-2)', letterSpacing: '0.12em', textAlign: 'center' }}>REPS / MIN</div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9, color: 'var(--ink-2)', letterSpacing: '0.12em', textAlign: 'center' }}>KG / RPE</div>
              <div/>
            </div>

            {sets[activeIdx].map((s, i) => (
              <div key={i} className="set-row">
                <div className="set-num" style={{ color: 'var(--rose)' }}>{i + 1}</div>
                <div className="set-input" style={{ background: 'rgba(91,28,46,0.06)', borderColor: 'rgba(91,28,46,0.15)' }}>
                  <input
                    value={s.reps}
                    placeholder={ex.reps || '—'}
                    onChange={e => updSet(activeIdx, i, 'reps', e.target.value)}
                    style={{ color: 'var(--ink)' }}
                  />
                </div>
                <div className="set-input" style={{ background: 'rgba(91,28,46,0.06)', borderColor: 'rgba(91,28,46,0.15)' }}>
                  <input
                    value={s.kg}
                    placeholder={ex.kind === 'cardio' ? 'rpe' : 'kg'}
                    onChange={e => updSet(activeIdx, i, 'kg', e.target.value)}
                    style={{ color: 'var(--ink)' }}
                  />
                </div>
                <button
                  className={'check rose ' + (s.done ? 'checked' : '')}
                  style={{ marginLeft: 'auto' }}
                  onClick={() => toggleSet(activeIdx, i)}
                >
                  <Icon.Check size={11} color="white"/>
                </button>
              </div>
            ))}

            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <button className="btn ghost btn-sm" style={{ flex: 1, color: 'var(--ink)', background: 'rgba(91,28,46,0.08)', borderColor: 'rgba(91,28,46,0.15)' }}>
                <Icon.Plus size={12}/> Set
              </button>
              <button
                className="btn ghost btn-sm"
                style={{ flex: 1, color: 'var(--ink)', background: 'rgba(91,28,46,0.08)', borderColor: 'rgba(91,28,46,0.15)' }}
                onClick={() => { setRestOpen(true); setRestLeft(90); }}>
                <Icon.Clock size={12}/> Descanso
              </button>
            </div>
          </div>
        </div>

        {/* TOOLS */}
        <div className="section-head">
          <span className="label">Material disponible</span>
        </div>
        <div className="pad" style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {DATA.tools.map((t, i) => (
            <span key={i} className="pill" style={{ fontSize: 9.5 }}>{t}</span>
          ))}
        </div>

        <div style={{ padding: '20px 18px 0' }}>
          <button className="btn primary btn-block">
            <Icon.Check size={14}/> Finalizar sesión
          </button>
        </div>
      </div>

      {/* REST TIMER SHEET */}
      <Sheet open={restOpen} onClose={() => setRestOpen(false)} title="Descanso">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px 0' }}>
          <div style={{ position: 'relative', width: 200, height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="200" height="200" viewBox="0 0 200 200" style={{ position: 'absolute', transform: 'rotate(-90deg)' }}>
              <circle cx="100" cy="100" r="88" fill="none" stroke="rgba(247,217,252,0.08)" strokeWidth="10"/>
              <circle cx="100" cy="100" r="88" fill="none" stroke="url(#restGrad)" strokeWidth="10" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 88}
                strokeDashoffset={2 * Math.PI * 88 * (1 - restLeft / 90)}
              />
              <defs>
                <linearGradient id="restGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#FAB940"/>
                  <stop offset="100%" stopColor="#E94F8B"/>
                </linearGradient>
              </defs>
            </svg>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 56, color: 'var(--lavender)', lineHeight: 1 }}>
                {String(Math.floor(restLeft / 60)).padStart(2, '0')}:{String(restLeft % 60).padStart(2, '0')}
              </div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.16em', color: 'var(--gold)', textTransform: 'uppercase', marginTop: 4 }}>
                respira · descansa
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 18, width: '100%' }}>
            <button className="btn ghost btn-block" onClick={() => setRestLeft(r => Math.max(0, r - 15))}>−15s</button>
            <button className="btn ghost btn-block" onClick={() => setRestLeft(r => r + 15)}>+15s</button>
          </div>
          <button className="btn primary btn-block" style={{ marginTop: 8 }} onClick={() => setRestOpen(false)}>
            Saltar descanso
          </button>
        </div>
      </Sheet>
    </>
  );
}

window.WorkoutScreen = WorkoutScreen;
