// OCR / smart-paste helpers for InBody + lab reports.
// Tries Claude vision (image) first; falls back to text extraction
// from a pasted block (lab PDF text, ticket transcription, etc.)

const INBODY_PROMPT = `Eres un extractor de datos. Te paso una imagen (o texto) de un ticket de InBody o báscula corporal. Devuelve UN SOLO objeto JSON con estas claves exactas (sin texto antes/después, sin código markdown):
{
  "weight": número en kg,
  "fat": % grasa corporal,
  "muscle": kg masa muscular,
  "water": % agua corporal,
  "visceral": nivel grasa visceral (entero),
  "bmr": kcal metabolismo basal
}
Si algún valor no se puede leer, omite esa clave. Acepta puntos o comas como decimal. Solo el JSON.`;

const LABS_PROMPT = `Eres un extractor de datos. Te paso una imagen (o texto) de un reporte de laboratorio bioquímico en español. Devuelve UN SOLO objeto JSON con estas claves exactas (sin texto antes/después, sin código markdown):
{
  "glucose": glucosa en ayunas en mg/dL,
  "homa": índice HOMA-IR,
  "trig": triglicéridos mg/dL,
  "alt": ALT (TGP/SGPT) U/L,
  "ast": AST (TGO/SGOT) U/L,
  "vitD": 25-OH vitamina D en ng/mL,
  "iron": hierro sérico µg/dL,
  "ferritin": ferritina ng/mL
}
Si algún valor no aparece, omite esa clave. Solo el JSON.`;

const MEASURES_PROMPT = `Eres un extractor de datos. Te paso una imagen o texto con medidas corporales. Devuelve UN SOLO objeto JSON con estas claves exactas (sin texto extra):
{
  "waist": cintura en cm,
  "hip": cadera en cm,
  "thigh": muslo en cm,
  "arm": brazo en cm,
  "chest": pecho en cm
}
Omite las claves cuyos valores no aparezcan. Solo el JSON.`;

const PROMPTS = { inbody: INBODY_PROMPT, labs: LABS_PROMPT, measures: MEASURES_PROMPT };

// Convert File → base64 + media type (strip "data:image/png;base64," prefix)
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const url = r.result;
      const [meta, b64] = url.split(',');
      const media = meta.match(/data:(.+);base64/)?.[1] || file.type || 'image/png';
      resolve({ media, data: b64, url });
    };
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function parseJSON(raw) {
  if (!raw) return null;
  // strip fences if present
  let s = raw.trim();
  s = s.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/, '');
  // find first { ... last }
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a === -1 || b === -1) return null;
  try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
}

// Try image (vision) first; fall back to text-only.
async function extractFromImage(file, kind = 'inbody') {
  const { media, data } = await fileToBase64(file);
  const prompt = PROMPTS[kind];
  try {
    const out = await window.claude.complete({
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: media, data } },
          { type: 'text', text: prompt },
        ],
      }],
    });
    return parseJSON(out);
  } catch (e) {
    console.warn('Vision extraction failed:', e);
    throw new Error('No se pudo procesar la imagen. Intenta pegar el texto del reporte.');
  }
}

async function extractFromText(text, kind = 'inbody') {
  const prompt = PROMPTS[kind];
  const out = await window.claude.complete({
    messages: [{ role: 'user', content: `${prompt}\n\n----- REPORTE -----\n${text}` }],
  });
  return parseJSON(out);
}

// ─── Reusable OCR capture component ───
function OcrCapture({ kind, onExtracted }) {
  const [mode, setMode] = useState('idle'); // idle | image | text | loading | done | error
  const [preview, setPreview] = useState(null);
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const fileInputRef = useRef(null);
  const onFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setMode('loading');
    setError('');
    try {
      const { url } = await fileToBase64(f);
      setPreview(url);
      const data = await extractFromImage(f, kind);
      if (!data || !Object.keys(data).length) {
        setError('No se detectaron valores. Prueba con una foto más clara o pega el texto.');
        setMode('error');
        return;
      }
      onExtracted(data);
      setMode('done');
    } catch (err) {
      setError(err.message || 'Error procesando la imagen.');
      setMode('error');
    }
  };

  const runText = async () => {
    if (!text.trim()) return;
    setMode('loading');
    setError('');
    try {
      const data = await extractFromText(text, kind);
      if (!data || !Object.keys(data).length) {
        setError('No se detectaron valores en el texto.');
        setMode('error');
        return;
      }
      onExtracted(data);
      setMode('done');
    } catch (err) {
      setError(err.message || 'Error procesando el texto.');
      setMode('error');
    }
  };

  return (
    <div style={{
      borderRadius: 16, padding: 12,
      background: 'linear-gradient(180deg, rgba(250,185,64,0.12), rgba(250,185,64,0.02))',
      border: '1px dashed rgba(250,185,64,0.4)',
      marginBottom: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <Icon.Sparkle size={14} color="#FAB940"/>
        <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--gold)', textTransform: 'uppercase' }}>
          Autocompletar con IA
        </div>
      </div>

      {mode === 'idle' && (
        <div style={{ display: 'flex', gap: 6 }}>
          <button
            onClick={() => fileInputRef.current?.click()}
            style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: 12, borderRadius: 12,
              background: 'rgba(247,217,252,0.06)',
              border: '1px solid var(--hairline)',
              color: 'var(--lavender)',
            }}>
            <Icon.Camera size={18} color="#FAB940"/>
            <span style={{ fontSize: 11, fontWeight: 500 }}>Foto / imagen</span>
            <span style={{ fontFamily: 'var(--fs-mono)', fontSize: 8.5, letterSpacing: '0.06em', opacity: 0.6 }}>ticket o pdf</span>
          </button>
          <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={onFile}/>
          <button
            onClick={() => setMode('text')}
            style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: 12, borderRadius: 12,
              background: 'rgba(247,217,252,0.06)',
              border: '1px solid var(--hairline)',
              color: 'var(--lavender)',
            }}>
            <Icon.Notebook size={18} color="#FAB940"/>
            <span style={{ fontSize: 11, fontWeight: 500 }}>Pegar texto</span>
            <span style={{ fontFamily: 'var(--fs-mono)', fontSize: 8.5, letterSpacing: '0.06em', opacity: 0.6 }}>desde el reporte</span>
          </button>
        </div>
      )}

      {mode === 'text' && (
        <div>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder={kind === 'labs'
              ? 'Pega aquí el texto del laboratorio…\nej. Glucosa en ayunas: 91 mg/dL\nHOMA-IR: 2.1\nTriglicéridos: 132…'
              : kind === 'measures'
              ? 'Pega o describe tus medidas…\nej. Cintura 78, cadera 102, muslo 58…'
              : 'Pega el contenido del ticket InBody…\nej. Peso 70.1 kg, grasa 28.4%…'}
            style={{
              width: '100%', minHeight: 110,
              background: 'rgba(247,217,252,0.06)',
              border: '1px solid var(--hairline)',
              borderRadius: 12, padding: 10,
              fontSize: 12, color: 'var(--lavender)',
              fontFamily: 'var(--fs-mono)',
              resize: 'none',
            }}/>
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            <button onClick={() => setMode('idle')} style={{
              flex: 1, padding: '8px 12px', borderRadius: 999,
              background: 'rgba(247,217,252,0.06)', border: '1px solid var(--hairline)',
              color: 'var(--muted)', fontSize: 12,
            }}>cancelar</button>
            <button onClick={runText} style={{
              flex: 2, padding: '8px 12px', borderRadius: 999,
              background: 'linear-gradient(180deg, var(--gold), var(--gold-deep))',
              color: 'var(--ink)', fontSize: 12, fontWeight: 600,
              boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.4)',
            }}>
              <Icon.Sparkle size={11} color="#1A0833" style={{ marginRight: 4, display: 'inline-block', verticalAlign: 'middle' }}/>
              extraer datos
            </button>
          </div>
        </div>
      )}

      {mode === 'loading' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 4px' }}>
          {preview && <img src={preview} alt="" style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover', border: '1px solid var(--hairline)' }}/>}
          <div className="ocr-spinner" style={{
            width: 18, height: 18, borderRadius: '50%',
            border: '2px solid rgba(250,185,64,0.2)',
            borderTopColor: 'var(--gold)',
            animation: 'spin 0.8s linear infinite',
          }}/>
          <span style={{ fontFamily: 'var(--fs-mono)', fontSize: 11, color: 'var(--gold)', letterSpacing: '0.1em' }}>
            extrayendo valores…
          </span>
        </div>
      )}

      {mode === 'done' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 4px' }}>
          {preview && <img src={preview} alt="" style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover', border: '1px solid var(--hairline)' }}/>}
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12.5, color: '#7BE2A8', fontWeight: 500 }}>
              <Icon.Check size={11} color="#7BE2A8" /> Campos autocompletados
            </div>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--muted)', letterSpacing: '0.06em', marginTop: 2 }}>
              revisa los valores abajo antes de guardar
            </div>
          </div>
          <button onClick={() => { setMode('idle'); setPreview(null); setText(''); }} style={{
            padding: '4px 10px', borderRadius: 999,
            background: 'rgba(247,217,252,0.06)', border: '1px solid var(--hairline)',
            fontSize: 10, color: 'var(--muted)', letterSpacing: '0.06em',
            fontFamily: 'var(--fs-mono)', textTransform: 'uppercase',
          }}>otra</button>
        </div>
      )}

      {mode === 'error' && (
        <div>
          <div style={{ fontSize: 12, color: 'var(--rose-glow)', marginBottom: 8, fontFamily: 'var(--fs-mono)', letterSpacing: '0.04em' }}>
            ✕ {error}
          </div>
          <button onClick={() => { setMode('idle'); setError(''); }} style={{
            padding: '6px 12px', borderRadius: 999,
            background: 'rgba(247,217,252,0.06)', border: '1px solid var(--hairline)',
            fontSize: 11, color: 'var(--muted)',
          }}>reintentar</button>
        </div>
      )}
    </div>
  );
}

window.OcrCapture = OcrCapture;
window.extractFromImage = extractFromImage;
window.extractFromText = extractFromText;
