// Today screen — supports day navigation, supp CRUD, workout swap
function TodayScreen() {
  const { state, actions } = useApp();
  const todayIdx = DATA.week.findIndex(d => d.today);
  const [dayIdx, setDayIdx] = useState(todayIdx);
  const day = DATA.week[dayIdx];
  const isToday = day.today;
  const supps = state.suppsByDay[day.num] || [];
  const anchors = state.anchorsByDay[day.num] || [];
  const workout = state.workoutByDay[day.num];

  const [editMode, setEditMode] = useState(false);
  const [suppSheet, setSuppSheet] = useState(null);    // null | {mode:'add'|'edit', supp}
  const [workoutSheet, setWorkoutSheet] = useState(false);

  const taken = supps.filter(s => s.taken).length;
  const totalSupps = supps.length || 1;
  const doneAnch = anchors.filter(a => a.done).length;
  const nextSupp = supps.find(s => !s.taken);

  const eyebrow = isToday
    ? `${day.dayLabel} · Día 9 · Sem 2`
    : `${day.dayLabel} · ${day.dateLabel}`;
  const headerTitle = isToday ? (
    <>hola,<br/><span className="accent">macy</span> <Icon.Sparkle size={28} color="#FAB940" style={{ display: 'inline-block', marginLeft: 2 }}/></>
  ) : (
    <><span style={{ fontStyle: 'italic' }}>{day.dayLabel.toLowerCase()}</span><br/><span className="accent">.</span><span style={{ fontStyle: 'italic' }}>{workout.kind.toLowerCase()}</span></>
  );

  return (
    <>
      <SparkleField count={6} />
      <div className="scroll" key={day.num}>
        {/* HEADER */}
        <div className="app-header">
          <div className="head-left">
            <span className="head-eyebrow">{eyebrow}</span>
            <h1>{headerTitle}</h1>
            <span className="head-date">{day.dateLabel} · 2026</span>
          </div>
          {!isToday ? (
            <button className="icon-btn" onClick={() => setDayIdx(todayIdx)} title="Hoy"
              style={{ width: 'auto', padding: '0 14px', borderRadius: 999 }}>
              <Icon.Chevron size={12} dir="left"/>
              <span style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', marginLeft: 4 }}>
                hoy
              </span>
            </button>
          ) : (
            <button className="icon-btn">
              <Icon.Bell size={16} />
              <span className="dot" />
            </button>
          )}
        </div>

        {/* DATE STRIP */}
        <div style={{ marginTop: 14 }}>
          <DateStrip week={DATA.week} selectedIdx={dayIdx} onPickIdx={setDayIdx}/>
        </div>

        {/* DAY'S WORKOUT */}
        <div style={{ padding: '20px 18px 0' }}>
          <div className={workout.type === 'rest' ? 'card-dark' : 'card-rose'} style={{ padding: 16, position: 'relative' }}>
            {workout.type !== 'rest' && <SparkleAccent />}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <span className="pill" style={{
                background: workout.type === 'rest' ? 'rgba(247,217,252,0.1)' : 'rgba(255,255,255,0.18)',
                borderColor: workout.type === 'rest' ? 'var(--hairline)' : 'rgba(255,255,255,0.25)',
                color: workout.type === 'rest' ? 'var(--lavender)' : 'white',
              }}>
                {WorkoutIcon(workout.type)} {isToday ? 'Hoy' : day.dayLabel} · {workout.kind}
              </span>
              <button
                onClick={() => setWorkoutSheet(true)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 4,
                  padding: '4px 8px', borderRadius: 999,
                  background: workout.type === 'rest' ? 'rgba(247,217,252,0.08)' : 'rgba(255,255,255,0.18)',
                  border: '1px solid ' + (workout.type === 'rest' ? 'var(--hairline)' : 'rgba(255,255,255,0.3)'),
                  color: workout.type === 'rest' ? 'var(--lavender)' : 'white',
                  fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase',
                }}>
                <Icon.Sync size={10}/> cambiar
              </button>
            </div>
            <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 30, lineHeight: 1, marginBottom: 6, color: workout.type === 'rest' ? 'var(--lavender)' : undefined }}>
              {workout.title}
            </div>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10.5, letterSpacing: '0.1em', opacity: 0.85, marginBottom: 14 }}>
              {workout.meta}
            </div>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.08em', opacity: 0.7, marginBottom: 14, textTransform: 'uppercase' }}>
              {workout.subtitle}
            </div>
            {workout.type !== 'rest' && (
              <button className="btn gold btn-block">
                <Icon.Play size={12}/> {day.past ? 'Ver detalle' : isToday ? 'Iniciar entreno' : 'Vista previa'}
              </button>
            )}
            {day.past && (
              <div style={{
                position: 'absolute', top: 12, right: 12,
                fontFamily: 'var(--fs-mono)', fontSize: 9, letterSpacing: '0.14em',
                background: 'rgba(123,226,168,0.18)', color: '#7BE2A8',
                padding: '3px 8px', borderRadius: 999,
                border: '1px solid rgba(123,226,168,0.3)',
                textTransform: 'uppercase',
              }}>✓ HECHO</div>
            )}
          </div>
        </div>

        {/* METRICS */}
        <div style={{ padding: '14px 18px 0' }}>
          <div className="metric-grid">
            <div className="metric">
              <div className="m-label">Suplem.</div>
              <div className="m-value">{taken}<span style={{ fontSize: 14, opacity: 0.5 }}>/{supps.length}</span></div>
              <div style={{ marginTop: 6 }}>
                <div className="progress" style={{ height: 4 }}>
                  <div className="fill" style={{ width: `${(taken / totalSupps) * 100}%` }}/>
                </div>
              </div>
            </div>
            <div className="metric">
              <div className="m-label">Anclas</div>
              <div className="m-value">{doneAnch}<span style={{ fontSize: 14, opacity: 0.5 }}>/{anchors.length || 1}</span></div>
              <div style={{ marginTop: 6 }}>
                <div className="progress" style={{ height: 4 }}>
                  <div className="fill" style={{ width: `${(doneAnch / Math.max(1, anchors.length)) * 100}%` }}/>
                </div>
              </div>
            </div>
            <div className="metric">
              <div className="m-label">{isToday ? 'Racha' : 'Día'}</div>
              <div className="m-value" style={{ color: 'var(--gold)' }}>
                {isToday ? <>12<span style={{ fontSize: 11, marginLeft: 2 }}>d</span></> : day.num - 3}
              </div>
              <div className="m-delta up" style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                {isToday ? (<><Icon.Flame size={10} color="#FAB940"/> en fuego</>) : <>de 84</>}
              </div>
            </div>
          </div>
        </div>

        {/* SUPLEMENTOS */}
        <div className="section-head">
          <span className="label">Suplementos · día {PROGRAM_DAY_BY_NUM[day.num]}</span>
          <button onClick={() => setEditMode(e => !e)}
            style={{
              fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em',
              color: editMode ? 'var(--gold)' : 'var(--muted)', textTransform: 'uppercase',
            }}>
            {editMode ? 'listo' : 'editar'}
          </button>
        </div>
        <div className="pad">
          {supps.map((s, i) => (
            <div key={s.uid} className={'supp-row ' + (s.next && !s.taken && isToday ? 'next' : '')}>
              {editMode && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginRight: 2 }}>
                  <button disabled={i === 0} onClick={() => actions.moveSupp(day.num, s.uid, 'up')}
                    style={{ width: 18, height: 14, color: i === 0 ? 'var(--muted-2)' : 'var(--lavender)' }}>
                    <Icon.Chevron size={10} dir="up"/>
                  </button>
                  <button disabled={i === supps.length - 1} onClick={() => actions.moveSupp(day.num, s.uid, 'down')}
                    style={{ width: 18, height: 14, color: i === supps.length - 1 ? 'var(--muted-2)' : 'var(--lavender)' }}>
                    <Icon.Chevron size={10} dir="down"/>
                  </button>
                </div>
              )}
              <div className={'supp-time ' + (s.next && !s.taken && isToday ? 'gold' : '')}>{s.time}</div>
              <div className="supp-info">
                <div className="nm">{s.emoji && <span style={{ marginRight: 4 }}>{s.emoji}</span>}{s.name}</div>
                <div className="ds">{s.dose}{s.tag && ` · ${s.tag}`}</div>
              </div>
              {editMode ? (
                <>
                  <button className="bell" onClick={() => setSuppSheet({ mode: 'edit', supp: s })} title="Editar">
                    <Icon.Settings size={13}/>
                  </button>
                  <button
                    onClick={() => actions.deleteSupp(day.num, s.uid)}
                    style={{
                      width: 28, height: 28, borderRadius: 8,
                      background: 'rgba(233,79,139,0.15)', color: 'var(--rose-glow)',
                      border: '1px solid rgba(233,79,139,0.3)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0,
                    }} title="Eliminar">
                    <Icon.Trash size={12}/>
                  </button>
                </>
              ) : (
                <>
                  <button
                    className={'bell ' + (s.alarmOn ? 'on' : '')}
                    onClick={() => setSuppSheet({ mode: 'edit', supp: s })}
                    title="Alarma">
                    {s.alarmOn ? <Icon.Bell size={14}/> : <Icon.BellOff size={14}/>}
                  </button>
                  <button
                    className={'check rose ' + (s.taken ? 'checked' : '')}
                    onClick={() => actions.toggleSupp(day.num, s.uid)}>
                    <Icon.Check size={11} color="white"/>
                  </button>
                </>
              )}
            </div>
          ))}
          <button className="btn ghost btn-block btn-sm" style={{ marginTop: 6 }}
            onClick={() => setSuppSheet({ mode: 'add', supp: null })}>
            <Icon.Plus size={14}/> Agregar suplemento
          </button>
        </div>

        {/* ANCLAS */}
        <div className="section-head">
          <span className="label">Anclas diarias</span>
          <span className="more">{doneAnch}/{anchors.length}</span>
        </div>
        <div className="pad">
          <div className="chip-grid">
            {anchors.map(a => {
              const Cmp = Icon[a.icon] || Icon.Sun;
              return (
                <button key={a.id}
                        className={'chip ' + (a.done ? 'done' : '')}
                        onClick={() => actions.toggleAnchor(day.num, a.id)}>
                  <span className="chip-icon"><Cmp size={14}/></span>
                  <span style={{ flex: 1 }}>{a.label}</span>
                  {a.done && <Icon.Check size={10} color="#FAB940"/>}
                </button>
              );
            })}
          </div>
        </div>

        {/* QUOTE */}
        <div style={{ padding: '20px 18px 0' }}>
          <div className="card-dark" style={{ textAlign: 'center', padding: '18px 14px' }}>
            <Icon.Sparkle size={14} color="#FAB940" style={{ marginBottom: 6 }}/>
            <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 17, lineHeight: 1.3, color: 'var(--lavender)' }}>
              "el cuerpo logra lo que la mente cree"
            </div>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.15em', color: 'var(--muted)', marginTop: 8 }}>
              MENSAJE DEL DÍA · SEMANA 2
            </div>
          </div>
        </div>
      </div>

      {/* Supp add/edit sheet */}
      {suppSheet && (
        <SuppEditSheet
          mode={suppSheet.mode}
          supp={suppSheet.supp}
          dayNum={day.num}
          onClose={() => setSuppSheet(null)}
        />
      )}

      {/* Workout swap sheet */}
      {workoutSheet && (
        <WorkoutSwapSheet
          current={workout.type}
          dayNum={day.num}
          onClose={() => setWorkoutSheet(false)}
        />
      )}
    </>
  );
}

// ─── Supp edit/add sheet ───
function SuppEditSheet({ mode, supp, dayNum, onClose }) {
  const { actions } = useApp();
  const [form, setForm] = useState(() => ({
    name: supp?.name || '',
    dose: supp?.dose || '',
    time: supp?.time || '08:00',
    tag:  supp?.tag  || 'diario',
    emoji: supp?.emoji || '💊',
    alarmOn: supp?.alarmOn ?? true,
    alarmReminder: supp?.alarmReminder ?? true,
  }));

  const save = () => {
    if (!form.name.trim()) { onClose(); return; }
    if (mode === 'add') {
      actions.addSupp(dayNum, form);
    } else {
      actions.updateSupp(dayNum, supp.uid, form);
    }
    onClose();
  };

  const remove = () => {
    if (mode === 'edit') actions.deleteSupp(dayNum, supp.uid);
    onClose();
  };

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <Sheet open={true} onClose={onClose} title={mode === 'add' ? 'Nuevo suplemento' : form.name || 'Suplemento'}>
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        {mode === 'add' ? 'agregar al día' : 'editar suplemento'}
      </div>
      <div className="hairline"/>

      <FormField label="Nombre">
        <input value={form.name} onChange={e => set('name', e.target.value)}
          placeholder="ej. Omega-3" style={{ textAlign: 'left' }}/>
      </FormField>

      <FormField label="Dosis · descripción">
        <input value={form.dose} onChange={e => set('dose', e.target.value)}
          placeholder="ej. 2g · con desayuno" style={{ textAlign: 'left' }}/>
      </FormField>

      <FormField label="Etiqueta">
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {['diario', 'ayunas', 'sueño', 'detox', 'antinflam.', 'personalizado'].map(t => (
            <button key={t} onClick={() => set('tag', t)}
              className={'pill ' + (form.tag === t ? 'solid-gold' : '')}
              style={{ fontSize: 9, padding: '4px 8px' }}>
              {t}
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="Emoji">
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {['💊','🫐','🦠','🌿','☀️','🟠','🐟','🌶️','🩸','🍋','🌙','🌊'].map(e => (
            <button key={e} onClick={() => set('emoji', e)}
              style={{
                width: 32, height: 32, borderRadius: 10, fontSize: 16,
                background: form.emoji === e ? 'rgba(250,185,64,0.18)' : 'rgba(247,217,252,0.06)',
                border: '1px solid ' + (form.emoji === e ? 'var(--gold)' : 'var(--hairline)'),
              }}>{e}</button>
          ))}
        </div>
      </FormField>

      <div className="hairline"/>

      <div className="row">
        <div className="row-main">
          <div className="row-title">Hora de alarma</div>
          <div className="row-sub">repite cada día</div>
        </div>
        <input type="time" value={form.time} onChange={e => set('time', e.target.value)}
          style={{
            color: 'var(--gold)', fontFamily: 'var(--fs-display)', fontStyle: 'italic',
            fontSize: 18, background: 'rgba(250,185,64,0.12)',
            padding: '6px 12px', borderRadius: 12, border: '1px solid rgba(250,185,64,0.3)',
            colorScheme: 'dark',
          }}/>
      </div>

      <div className="row">
        <div className="row-main">
          <div className="row-title">Notificación</div>
          <div className="row-sub">push + sonido suave</div>
        </div>
        <Toggle on={form.alarmOn} onChange={v => set('alarmOn', v)}/>
      </div>

      <div className="row">
        <div className="row-main">
          <div className="row-title">Recordatorio si la olvidas</div>
          <div className="row-sub">+15 min después</div>
        </div>
        <Toggle on={form.alarmReminder} onChange={v => set('alarmReminder', v)}/>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
        {mode === 'edit' && (
          <button className="btn ghost btn-block" onClick={remove}
            style={{ color: 'var(--rose-glow)', borderColor: 'rgba(233,79,139,0.3)' }}>
            <Icon.Trash size={12}/> Eliminar
          </button>
        )}
        <button className="btn primary btn-block" onClick={save}>
          <Icon.Check size={14}/> Guardar
        </button>
      </div>
    </Sheet>
  );
}

// ─── Workout swap sheet ───
function WorkoutSwapSheet({ current, dayNum, onClose }) {
  const { actions } = useApp();
  const opts = Object.entries(DEFAULT_WORKOUT_TYPES);

  return (
    <Sheet open={true} onClose={onClose} title="Cambiar entreno">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 12 }}>
        elige el tipo para este día
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {opts.map(([key, t]) => {
          const selected = key === current;
          return (
            <button key={key}
              onClick={() => { actions.swapWorkout(dayNum, key); onClose(); }}
              style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '14px 16px', borderRadius: 16, textAlign: 'left',
                background: selected ? 'linear-gradient(135deg, rgba(250,185,64,0.18), rgba(250,185,64,0.04))' : 'rgba(247,217,252,0.04)',
                border: '1px solid ' + (selected ? 'rgba(250,185,64,0.5)' : 'var(--hairline-2)'),
              }}>
              <div style={{
                width: 38, height: 38, borderRadius: 12,
                background: selected ? 'linear-gradient(180deg, var(--gold), var(--gold-deep))' : 'rgba(247,217,252,0.08)',
                color: selected ? 'var(--ink)' : 'var(--gold)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                {WorkoutIcon(t.type, 18)}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 600 }}>{t.title}</div>
                <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, color: 'var(--muted)', marginTop: 2, letterSpacing: '0.06em' }}>
                  {t.meta}
                </div>
              </div>
              {selected && <Icon.Check size={14} color="#FAB940"/>}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}

function FormField({ label, children }) {
  return (
    <div className="row">
      <div className="row-main">
        <div className="row-title">{label}</div>
      </div>
      <div style={{ flex: 1.4, display: 'flex', justifyContent: 'flex-end' }}>
        {React.Children.count(children) === 1 && children.type === 'input' ? (
          <div className="field" style={{ flex: 1, maxWidth: 200 }}>{children}</div>
        ) : children}
      </div>
    </div>
  );
}

function WorkoutIcon(type, size = 10) {
  const m = { fuerza: 'Dumbbell', cardio: 'Heart', yoga: 'Wind', hiking: 'Walk', rest: 'Moon' };
  const C = Icon[m[type]] || Icon.Heart;
  return <C size={size}/>;
}

function SparkleAccent() {
  return (
    <>
      <Icon.Sparkle size={12} color="#FAB940" style={{ position: 'absolute', top: 14, right: 60, opacity: 0.6 }}/>
      <Icon.Sparkle size={8} color="#F7D9FC" style={{ position: 'absolute', bottom: 18, right: 30, opacity: 0.5 }}/>
    </>
  );
}

function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange && onChange(!on)}
      style={{
        width: 50, height: 30, borderRadius: 999,
        background: on ? 'linear-gradient(180deg, #FAB940, #E89A1F)' : 'rgba(247,217,252,0.12)',
        position: 'relative',
        boxShadow: on ? 'inset 0 1px 2px rgba(255,255,255,0.4), 0 0 12px rgba(250,185,64,0.3)' : 'inset 0 1px 2px rgba(0,0,0,0.2)',
        transition: 'all 0.2s',
      }}>
      <div style={{
        position: 'absolute', top: 3, left: on ? 23 : 3,
        width: 24, height: 24, borderRadius: '50%',
        background: 'white',
        boxShadow: '0 2px 4px rgba(0,0,0,0.2), inset 0 -1px 1px rgba(0,0,0,0.1)',
        transition: 'left 0.2s ease',
      }}/>
    </button>
  );
}

window.TodayScreen = TodayScreen;
window.Toggle = Toggle;
window.FormField = FormField;
