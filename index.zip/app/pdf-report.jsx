// Printable medical report — opens a new tab with a clean, doctor-friendly layout
// then triggers the print dialog. User can Save as PDF from there.

function buildSparklineSVG(series, width = 520, height = 90, color = '#C2286B') {
  if (!series.length) return '';
  const vals = series.map(s => s.v);
  const max = Math.max(...vals), min = Math.min(...vals);
  const range = (max - min) || 1;
  const pad = range * 0.15;
  const yMax = max + pad, yMin = min - pad;
  const yRange = yMax - yMin || 1;

  const pts = series.map((s, i) => {
    const x = series.length === 1 ? width / 2 : (i / (series.length - 1)) * (width - 40) + 20;
    const y = height - ((s.v - yMin) / yRange) * (height - 24) - 12;
    return [x, y, s];
  });

  const path = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0] + ' ' + p[1]).join(' ');
  const area = path + ` L ${pts[pts.length-1][0]} ${height} L ${pts[0][0]} ${height} Z`;

  const labels = pts.map(p => `
    <g>
      <circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="${color}"/>
      <text x="${p[0]}" y="${p[1] - 8}" fill="#1A0833"
            font-family="Georgia, serif" font-style="italic" font-size="11"
            text-anchor="middle">${p[2].v}</text>
      <text x="${p[0]}" y="${height + 14}" fill="#666"
            font-family="ui-monospace, monospace" font-size="9"
            text-anchor="middle">${p[2].d}</text>
    </g>`).join('');

  return `
    <svg width="${width}" height="${height + 24}" viewBox="0 0 ${width} ${height + 24}"
         xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="g${color.replace('#','')}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${color}" stop-opacity="0.25"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
        </linearGradient>
      </defs>
      ${pts.length > 1 ? `<path d="${area}" fill="url(#g${color.replace('#','')})"/>` : ''}
      ${pts.length > 1 ? `<path d="${path}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>` : ''}
      ${labels}
    </svg>
  `;
}

const LAB_REF = {
  glucose:  { label: 'Glucosa en ayunas', unit: 'mg/dL', range: '70 – 99' },
  homa:     { label: 'HOMA-IR',           unit: '',      range: '< 2.5' },
  trig:     { label: 'Triglicéridos',     unit: 'mg/dL', range: '< 150' },
  alt:      { label: 'ALT (TGP)',         unit: 'U/L',   range: '7 – 35' },
  ast:      { label: 'AST (TGO)',         unit: 'U/L',   range: '8 – 33' },
  vitD:     { label: 'Vitamina D 25-OH',  unit: 'ng/mL', range: '30 – 80' },
  iron:     { label: 'Hierro sérico',     unit: 'µg/dL', range: '60 – 170' },
  ferritin: { label: 'Ferritina',         unit: 'ng/mL', range: '15 – 150' },
};

const INBODY_REF = {
  weight:   { label: 'Peso',                  unit: 'kg' },
  fat:      { label: 'Grasa corporal',        unit: '%' },
  muscle:   { label: 'Masa muscular',         unit: 'kg' },
  water:    { label: 'Agua corporal',         unit: '%' },
  visceral: { label: 'Grasa visceral',        unit: 'lvl' },
  bmr:      { label: 'Metabolismo basal',     unit: 'kcal' },
};

const MEASURES_REF = {
  waist: { label: 'Cintura' },
  hip:   { label: 'Cadera' },
  thigh: { label: 'Muslo' },
  arm:   { label: 'Brazo' },
  chest: { label: 'Pecho' },
};

function fmtToday() {
  const months = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
  const d = new Date(2026, 4, 12);
  return `${d.getDate()} de ${months[d.getMonth()]} de ${d.getFullYear()}`;
}

function buildReportHTML(state) {
  const profile = state.profile;
  const inbody = state.inbodyHistory || [];
  const labs   = state.labsHistory || [];
  const meas   = state.measuresHistory || [];

  const inbodyTable = inbody.length ? `
    <table>
      <thead>
        <tr>
          <th>Métrica</th>
          ${inbody.map(h => `<th>${h.label}</th>`).join('')}
          <th>Δ total</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(INBODY_REF).map(([k, ref]) => {
          if (inbody[0][k] === undefined) return '';
          const first = inbody[0][k];
          const last  = inbody[inbody.length-1][k];
          const delta = +(last - first).toFixed(1);
          return `
            <tr>
              <td class="metric-name">${ref.label} <span class="unit">${ref.unit}</span></td>
              ${inbody.map(h => `<td>${h[k] ?? '—'}</td>`).join('')}
              <td class="delta ${delta < 0 ? 'down' : delta > 0 ? 'up' : ''}">${delta === 0 ? '—' : (delta > 0 ? '+' : '') + delta}</td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  ` : '<p class="empty">Sin registros de InBody.</p>';

  const labsTable = labs.length ? `
    <table>
      <thead>
        <tr>
          <th>Analito</th>
          <th>Rango</th>
          ${labs.map(h => `<th>${h.label}</th>`).join('')}
          <th>Δ total</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(LAB_REF).map(([k, ref]) => {
          if (labs[0][k] === undefined) return '';
          const first = labs[0][k];
          const last  = labs[labs.length-1][k];
          const delta = +(last - first).toFixed(1);
          const isGood = ['glucose','homa','trig','alt','ast'].includes(k) ? delta < 0 : delta > 0;
          return `
            <tr>
              <td class="metric-name">${ref.label} <span class="unit">${ref.unit}</span></td>
              <td class="range">${ref.range}</td>
              ${labs.map(h => `<td>${h[k] ?? '—'}</td>`).join('')}
              <td class="delta ${delta === 0 ? '' : isGood ? 'down' : 'up'}">${delta === 0 ? '—' : (delta > 0 ? '+' : '') + delta}</td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  ` : '<p class="empty">Sin laboratorios registrados.</p>';

  const measTable = meas.length ? `
    <table>
      <thead>
        <tr>
          <th>Medida (cm)</th>
          ${meas.map(h => `<th>${h.label}</th>`).join('')}
          <th>Δ total</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(MEASURES_REF).map(([k, ref]) => {
          if (meas[0][k] === undefined) return '';
          const first = meas[0][k];
          const last  = meas[meas.length-1][k];
          const delta = +(last - first).toFixed(1);
          return `
            <tr>
              <td class="metric-name">${ref.label}</td>
              ${meas.map(h => `<td>${h[k] ?? '—'}</td>`).join('')}
              <td class="delta ${delta < 0 ? 'down' : delta > 0 ? 'up' : ''}">${delta === 0 ? '—' : (delta > 0 ? '+' : '') + delta}</td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  ` : '<p class="empty">Sin medidas registradas.</p>';

  // Selected key trend charts
  const weightSVG = inbody.length > 0 ? buildSparklineSVG(
    inbody.map(h => ({ d: h.label.split(' ')[0] + ' ' + (h.label.split(' ')[1] || ''), v: h.weight })),
    520, 90, '#C2286B') : '';

  const fatSVG = inbody.length > 0 ? buildSparklineSVG(
    inbody.map(h => ({ d: h.label.split(' ')[0] + ' ' + (h.label.split(' ')[1] || ''), v: h.fat })),
    520, 90, '#E89A1F') : '';

  const homaSVG = labs.length > 0 ? buildSparklineSVG(
    labs.map(h => ({ d: h.label, v: h.homa })),
    520, 90, '#5B1C2E') : '';

  const altSVG = labs.length > 0 ? buildSparklineSVG(
    labs.map(h => ({ d: h.label, v: h.alt })),
    520, 90, '#25104D') : '';

  return `<!doctype html>
<html lang="es"><head>
<meta charset="utf-8"/>
<title>Reporte de salud · ${profile.name}</title>
<style>
  @page { size: letter; margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body {
    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    color: #1a1a1a; margin: 0; padding: 28px;
    background: #fff;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  h1 { font-family: Georgia, 'Times New Roman', serif; font-style: italic; font-weight: normal;
       font-size: 36px; line-height: 1; margin: 0; color: #5B1C2E; letter-spacing: -0.02em; }
  h2 { font-family: Georgia, serif; font-style: italic; font-weight: normal;
       font-size: 20px; margin: 24px 0 10px; color: #1a1a1a;
       border-bottom: 2px solid #C2286B; padding-bottom: 6px; display: flex; align-items: baseline; justify-content: space-between; }
  h2 .h2-sub { font-family: ui-monospace, monospace; font-size: 10px; font-style: normal;
               color: #888; letter-spacing: 0.14em; text-transform: uppercase; }
  .eyebrow { font-family: ui-monospace, monospace; font-size: 10px; letter-spacing: 0.18em;
             color: #C2286B; text-transform: uppercase; margin-bottom: 8px; }
  header { display: flex; justify-content: space-between; align-items: flex-end;
           border-bottom: 3px double #C2286B; padding-bottom: 14px; margin-bottom: 18px; }
  .meta { font-size: 11px; color: #666; line-height: 1.6; text-align: right;
          font-family: ui-monospace, monospace; letter-spacing: 0.04em; }
  .meta strong { color: #1a1a1a; }
  .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 14px 0 6px; }
  .summary .card {
    border: 1px solid #ddd; border-radius: 6px; padding: 10px 12px;
    background: #fafafa;
  }
  .summary .k {
    font-family: ui-monospace, monospace; font-size: 9px; letter-spacing: 0.12em;
    color: #888; text-transform: uppercase;
  }
  .summary .v {
    font-family: Georgia, serif; font-style: italic; font-size: 22px;
    color: #1a1a1a; margin-top: 4px;
  }
  .summary .v .u { font-size: 11px; color: #888; font-style: normal; margin-left: 2px; }
  .summary .d { font-family: ui-monospace, monospace; font-size: 9.5px; margin-top: 2px; letter-spacing: 0.06em; }
  .summary .d.down { color: #1b6e3a; }
  .summary .d.up { color: #a51f4d; }

  table { width: 100%; border-collapse: collapse; margin: 8px 0 4px; font-size: 11px; }
  thead th {
    background: #25104D; color: #fff; font-weight: 600;
    text-align: center; padding: 7px 6px;
    font-family: ui-monospace, monospace; font-size: 9.5px;
    letter-spacing: 0.08em; text-transform: uppercase;
  }
  thead th:first-child { text-align: left; }
  tbody td { padding: 6px 7px; text-align: center; border-bottom: 1px solid #eee; }
  tbody td.metric-name { text-align: left; font-weight: 500; color: #1a1a1a; }
  tbody td .unit { color: #888; font-weight: normal; font-size: 9.5px; font-family: ui-monospace, monospace; margin-left: 3px; }
  tbody td.range { color: #666; font-size: 10px; font-family: ui-monospace, monospace; }
  tbody td.delta { font-family: Georgia, serif; font-style: italic; font-weight: 500; }
  tbody td.delta.up { color: #a51f4d; }
  tbody td.delta.down { color: #1b6e3a; }
  tbody tr:nth-child(even) { background: #fafafa; }

  .trend { margin: 6px 0 4px; }
  .trend-label {
    font-family: ui-monospace, monospace; font-size: 9.5px; letter-spacing: 0.14em;
    color: #888; text-transform: uppercase; margin-bottom: 2px;
  }
  .trends { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 12px 0; }
  .trends svg { display: block; }

  footer {
    margin-top: 26px; padding-top: 14px;
    border-top: 1px solid #ccc;
    font-family: ui-monospace, monospace; font-size: 9.5px;
    color: #888; letter-spacing: 0.06em;
    display: flex; justify-content: space-between;
  }
  .notes {
    background: #FFF6E8; border: 1px solid #FAB940; border-radius: 6px;
    padding: 10px 14px; margin: 10px 0 16px;
    font-size: 11px; color: #5a4400; line-height: 1.5;
  }
  .empty { color: #888; font-style: italic; font-size: 11px; margin: 8px 0; }
  .print-btn {
    position: fixed; top: 16px; right: 16px;
    background: #C2286B; color: white; border: 0;
    padding: 10px 18px; border-radius: 999px;
    font-family: ui-monospace, monospace; font-size: 11px;
    letter-spacing: 0.12em; text-transform: uppercase; cursor: pointer;
    box-shadow: 0 6px 16px rgba(194,40,107,0.4);
    z-index: 100;
  }
  @media print { .print-btn { display: none; } body { padding: 0; } }
</style>
</head><body>
  <button class="print-btn" onclick="window.print()">⎙ Imprimir / Guardar PDF</button>

  <header>
    <div>
      <div class="eyebrow">Reporte de salud · App Hábitos</div>
      <h1>${profile.name}</h1>
    </div>
    <div class="meta">
      <strong>Fecha de impresión</strong> · ${fmtToday()}<br/>
      Programa · semana ${profile.programWeek} de ${profile.programTotal}<br/>
      ${profile.age} años · ${profile.height} cm · FC máx ${profile.fcMax}
    </div>
  </header>

  <div class="notes">
    <strong>Objetivo del programa:</strong> ${profile.goal}<br/>
    <strong>Antecedentes:</strong> ${profile.personal.conditions}<br/>
    <strong>Medicamentos:</strong> ${profile.personal.meds || '—'} · <strong>Alergias:</strong> ${profile.personal.allergies || '—'}
  </div>

  ${inbody.length ? `
  <h2>Composición corporal · InBody <span class="h2-sub">${inbody.length} registros</span></h2>
  <div class="summary">
    ${(() => {
      const first = inbody[0], last = inbody[inbody.length - 1];
      return ['weight','fat','muscle','visceral'].map(k => {
        const ref = INBODY_REF[k];
        const delta = +(last[k] - first[k]).toFixed(1);
        const isGood = (k === 'muscle') ? delta > 0 : delta < 0;
        return `
          <div class="card">
            <div class="k">${ref.label}</div>
            <div class="v">${last[k]}<span class="u">${ref.unit}</span></div>
            <div class="d ${delta === 0 ? '' : isGood ? 'down' : 'up'}">
              ${delta === 0 ? '— sin cambio' : (delta > 0 ? '↑ +' : '↓ ') + Math.abs(delta) + ' desde inicio'}
            </div>
          </div>`;
      }).join('');
    })()}
  </div>
  ${inbodyTable}
  <div class="trends">
    <div class="trend"><div class="trend-label">Peso (kg)</div>${weightSVG}</div>
    <div class="trend"><div class="trend-label">Grasa corporal (%)</div>${fatSVG}</div>
  </div>
  ` : ''}

  ${labs.length ? `
  <h2>Bioquímica clínica · Laboratorios <span class="h2-sub">${labs.length} estudios</span></h2>
  ${labsTable}
  <div class="trends">
    <div class="trend"><div class="trend-label">HOMA-IR (resistencia a la insulina)</div>${homaSVG}</div>
    <div class="trend"><div class="trend-label">ALT · TGP (hígado)</div>${altSVG}</div>
  </div>
  ` : ''}

  ${meas.length ? `
  <h2>Medidas antropométricas <span class="h2-sub">${meas.length} mediciones</span></h2>
  ${measTable}
  ` : ''}

  <footer>
    <div>Generado por App Hábitos · v0.9</div>
    <div>${profile.name} · ${fmtToday()}</div>
  </footer>
</body></html>`;
}

function exportHealthReport(state) {
  const html = buildReportHTML(state);
  const w = window.open('', '_blank');
  if (!w) {
    alert('Habilita los pop-ups para exportar el reporte.');
    return;
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
  // Defer print prompt to let layout settle
  setTimeout(() => { try { w.focus(); } catch (e) {} }, 300);
}

window.exportHealthReport = exportHealthReport;
