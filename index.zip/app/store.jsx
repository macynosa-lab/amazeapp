// ─── Global store (React context + localStorage persistence) ───
const AppContext = React.createContext(null);
const STORAGE_KEY = 'app-habitos-v1';

const DEFAULT_WORKOUT_TYPES = {
  fuerza: { kind: 'Fuerza',     title: 'Fuerza',          subtitle: 'Full body · cadena posterior',  meta: '45 MIN · RPE 5-6 · 7 EJERCICIOS',  type: 'fuerza' },
  cardio: { kind: 'Cardio Z2',  title: 'Cardio · Zona 2', subtitle: 'Caminadora + activación glúteos', meta: '45 MIN · RPE 5-6 · 114–125 LPM',   type: 'cardio' },
  yoga:   { kind: 'Yoga/Pilates', title: 'Yoga · Pilates', subtitle: 'Glúteos + core profundo',       meta: '35 MIN · POLAINAS 1 KG',           type: 'yoga' },
  hiking: { kind: 'Hiking',     title: 'Hiking',           subtitle: 'Terreno con pendiente suave',   meta: '70 MIN · Z2-3 CONVERSACIONAL',     type: 'hiking' },
  rest:   { kind: 'Descanso',   title: 'Descanso activo',  subtitle: 'Yin yoga · paseo · planificación', meta: '20-30 MIN · OPCIONAL',          type: 'rest' },
};

function getInitialState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}

  // build per-day supps with alarmOn flag
  const suppsByDay = {};
  DATA.week.forEach((d) => {
    const pd = PROGRAM_DAY_BY_NUM[d.num];
    const isToday = d.today;
    const list = suppsForDayWithStatus(pd, {
      takenUntilTime: isToday ? '07:30' : null,
      markNext: isToday,
      allTaken: d.past,
    });
    suppsByDay[d.num] = list.map((s, i) => ({
      ...s,
      uid: `${d.num}-${s.id}-${i}`,
      alarmOn: true,
      alarmReminder: true,
    }));
  });

  const anchorsByDay = {};
  DATA.week.forEach((d, i) => {
    const todayIdx = DATA.week.findIndex(x => x.today);
    anchorsByDay[d.num] = i === todayIdx
      ? [...DATA.today.anchors]
      : DATA.today.anchors.map(a => ({ ...a, done: d.past ? Math.random() > 0.2 : false }));
  });

  const workoutByDay = {};
  DATA.week.forEach(d => {
    workoutByDay[d.num] = { type: d.type, title: d.title, subtitle: d.subtitle, meta: d.meta, kind: d.kind };
  });

  return {
    suppsByDay,
    anchorsByDay,
    workoutByDay,
    profile: {
      name: 'Macy',
      age: 30,
      fcMax: 190,
      height: 165,
      goal: 'Revertir resistencia a la insulina + hígado graso',
      goalWeight: 65,
      programWeek: 2,
      programTotal: 12,
      connections: { health: true, watch: true, scale: false },
      reminders: { rest: true, hydration: true, posture: false, sleep: true },
      notifications: { push: true, sound: true, vibration: true, summary: true },
      personal: { allergies: 'Penicilina', conditions: 'RI, hígado graso, ferritina baja', meds: 'Sertralina, Axcion' },
    },
    inbodyHistory: [
      { date: '2026-03-15', label: '15 mar 2026', weight: 72.4, fat: 31.2, muscle: 25.9, water: 50.4, visceral: 9,  bmr: 1380 },
      { date: '2026-04-12', label: '12 abr 2026', weight: 71.2, fat: 29.8, muscle: 26.3, water: 51.2, visceral: 8,  bmr: 1395 },
      { date: '2026-05-10', label: '10 may 2026', weight: 70.1, fat: 28.4, muscle: 26.8, water: 52.1, visceral: 7,  bmr: 1412 },
    ],
    labsHistory: [
      { date: '2026-02-10', label: 'Feb 2026', glucose: 108, homa: 4.2, trig: 198, alt: 48, ast: 36, vitD: 18, iron: 52, ferritin: 12 },
      { date: '2026-04-28', label: 'Abr 2026', glucose: 91,  homa: 2.1, trig: 132, alt: 28, ast: 24, vitD: 22, iron: 65, ferritin: 18 },
    ],
    measuresHistory: [
      { date: '2026-03-15', label: '15 mar', waist: 82.5, hip: 104, thigh: 60.5, arm: 28,   chest: 93 },
      { date: '2026-04-12', label: '12 abr', waist: 80.5, hip: 103, thigh: 59.2, arm: 28,   chest: 92.5 },
      { date: '2026-05-10', label: '10 may', waist: 78,   hip: 102, thigh: 58,   arm: 28,   chest: 92 },
    ],
  };
}

function AppProvider({ children }) {
  const [state, setStateRaw] = useState(getInitialState);

  // persist
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
  }, [state]);

  const update = (patch) => {
    setStateRaw(s => typeof patch === 'function' ? patch(s) : { ...s, ...patch });
  };

  const actions = {
    // ─── supplements
    toggleSupp(dayNum, uid) {
      update(s => ({
        ...s,
        suppsByDay: {
          ...s.suppsByDay,
          [dayNum]: s.suppsByDay[dayNum].map(x => x.uid === uid ? { ...x, taken: !x.taken } : x),
        },
      }));
    },
    updateSupp(dayNum, uid, patch) {
      update(s => ({
        ...s,
        suppsByDay: {
          ...s.suppsByDay,
          [dayNum]: s.suppsByDay[dayNum].map(x => x.uid === uid ? { ...x, ...patch } : x).sort((a, b) => a.time.localeCompare(b.time)),
        },
      }));
    },
    deleteSupp(dayNum, uid) {
      update(s => ({
        ...s,
        suppsByDay: {
          ...s.suppsByDay,
          [dayNum]: s.suppsByDay[dayNum].filter(x => x.uid !== uid),
        },
      }));
    },
    addSupp(dayNum, supp) {
      update(s => {
        const list = s.suppsByDay[dayNum] || [];
        const newSupp = {
          uid: `c-${Date.now()}`,
          time: '08:00', name: 'Nuevo suplemento', dose: '', tag: 'personalizado',
          emoji: '💊', taken: false, next: false,
          alarmOn: true, alarmReminder: true,
          ...supp,
        };
        return {
          ...s,
          suppsByDay: {
            ...s.suppsByDay,
            [dayNum]: [...list, newSupp].sort((a, b) => a.time.localeCompare(b.time)),
          },
        };
      });
    },
    moveSupp(dayNum, uid, dir) {
      update(s => {
        const list = [...(s.suppsByDay[dayNum] || [])];
        const idx = list.findIndex(x => x.uid === uid);
        if (idx === -1) return s;
        const next = idx + (dir === 'up' ? -1 : 1);
        if (next < 0 || next >= list.length) return s;
        [list[idx], list[next]] = [list[next], list[idx]];
        return { ...s, suppsByDay: { ...s.suppsByDay, [dayNum]: list } };
      });
    },

    // ─── anchors
    toggleAnchor(dayNum, id) {
      update(s => ({
        ...s,
        anchorsByDay: {
          ...s.anchorsByDay,
          [dayNum]: s.anchorsByDay[dayNum].map(x => x.id === id ? { ...x, done: !x.done } : x),
        },
      }));
    },

    // ─── workout swap
    swapWorkout(dayNum, newType) {
      const tpl = DEFAULT_WORKOUT_TYPES[newType];
      if (!tpl) return;
      update(s => ({
        ...s,
        workoutByDay: { ...s.workoutByDay, [dayNum]: { ...tpl } },
      }));
    },

    // ─── profile
    updateProfile(patch) {
      update(s => ({ ...s, profile: { ...s.profile, ...patch } }));
    },
    updateProfileSection(section, patch) {
      update(s => ({ ...s, profile: { ...s.profile, [section]: { ...s.profile[section], ...patch } } }));
    },

    // ─── health imports
    addInbody(entry) {
      update(s => ({ ...s, inbodyHistory: [...s.inbodyHistory, entry].sort((a, b) => a.date.localeCompare(b.date)) }));
    },
    addLabs(entry) {
      update(s => ({ ...s, labsHistory: [...s.labsHistory, entry].sort((a, b) => a.date.localeCompare(b.date)) }));
    },
    addMeasures(entry) {
      update(s => ({ ...s, measuresHistory: [...s.measuresHistory, entry].sort((a, b) => a.date.localeCompare(b.date)) }));
    },

    resetAll() {
      try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
      setStateRaw(getInitialState());
    },
  };

  return (
    <AppContext.Provider value={{ state, actions }}>
      {children}
    </AppContext.Provider>
  );
}

function useApp() {
  const ctx = React.useContext(AppContext);
  if (!ctx) throw new Error('useApp must be inside AppProvider');
  return ctx;
}

Object.assign(window, { AppContext, AppProvider, useApp, DEFAULT_WORKOUT_TYPES });
