// UI primitives — shared across screens
const { useState, useEffect, useMemo, useRef } = React;

// ─── Decorative sparkles backdrop ───
function SparkleField({ count = 8 }) {
  const stars = useMemo(() => {
    const list = [];
    for (let i = 0; i < count; i++) {
      list.push({
        top: Math.random() * 90 + 5,
        left: Math.random() * 90 + 5,
        size: 8 + Math.random() * 14,
        delay: Math.random() * 3,
        color: ['#FAB940', '#E94F8B', '#F7D9FC'][Math.floor(Math.random() * 3)],
      });
    }
    return list;
  }, [count]);

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 1 }}>
      {stars.map((s, i) => (
        <Icon.Sparkle key={i} size={s.size} color={s.color} style={{
          position: 'absolute', top: s.top + '%', left: s.left + '%',
          animation: `twinkle 3s ease-in-out ${s.delay}s infinite`,
          opacity: 0.5,
        }} />
      ))}
    </div>
  );
}

// ─── Status bar (matches iOS) ───
function StatusBar({ time = '9:41' }) {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, zIndex: 30,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '16px 28px 0', height: 54, color: 'var(--lavender)',
    }}>
      <div style={{ fontSize: 15, fontWeight: 600, fontFamily: '-apple-system, system-ui' }}>{time}</div>
      <div style={{ width: 84 }} />
      <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11">
          <rect x="0" y="6"  width="2.8" height="4" rx="0.6" fill="currentColor"/>
          <rect x="4" y="4"  width="2.8" height="6" rx="0.6" fill="currentColor"/>
          <rect x="8" y="2"  width="2.8" height="8" rx="0.6" fill="currentColor"/>
          <rect x="12" y="0" width="2.8" height="10" rx="0.6" fill="currentColor"/>
        </svg>
        <svg width="15" height="11" viewBox="0 0 15 11" fill="currentColor">
          <path d="M7.5 2.7 c2 0 3.8 0.8 5.2 2.1 l1-1 c-1.6-1.6-3.8-2.6-6.2-2.6 s-4.6 1-6.2 2.6 l1 1 c1.4-1.3 3.2-2.1 5.2-2.1z"/>
          <path d="M7.5 6 c1.2 0 2.3 0.5 3.1 1.3 l1-1 c-1.1-1.1-2.6-1.7-4.1-1.7 s-3 0.6-4.1 1.7 l1 1 C5.2 6.5 6.3 6 7.5 6z"/>
          <circle cx="7.5" cy="9.5" r="1.3"/>
        </svg>
        <svg width="24" height="11" viewBox="0 0 24 11">
          <rect x="0.5" y="0.5" width="21" height="10" rx="3" stroke="currentColor" fill="none" opacity="0.5"/>
          <rect x="2" y="2" width="18" height="7" rx="1.5" fill="currentColor"/>
          <path d="M22.5 4 V7 c0.7-0.2 1.2-0.8 1.2-1.5 s-0.5-1.3-1.2-1.5z" fill="currentColor" opacity="0.5"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Sparkle Star inline ───
function Star({ size = 12, color = '#FAB940', style = {} }) {
  return <Icon.Sparkle size={size} color={color} style={style} />;
}

// ─── Date Strip ───
function DateStrip({ week, onPick, selectedIdx, onPickIdx }) {
  return (
    <div className="date-strip">
      {week.map((d, i) => {
        const isSel = selectedIdx === i;
        const cls = [
          'date-cell',
          d.today ? 'today' : '',
          isSel && !d.today ? 'selected' : '',
        ].filter(Boolean).join(' ');
        return (
          <button key={i} className={cls} onClick={() => {
            onPickIdx && onPickIdx(i);
            onPick && onPick(d);
          }}>
            <div className="dow">{d.dow}</div>
            <div className="num">{d.num}</div>
            <div className="dot-row">
              <span className={'dot ' + (d.done || d.workouts > 0 ? 'done' : '')} />
              <span className={'dot ' + (d.supps > 5 ? 'rose' : d.supps > 0 ? 'done' : '')} />
            </div>
          </button>
        );
      })}
    </div>
  );
}

// ─── Tab Bar ───
function TabBar({ active, setActive }) {
  const tabs = [
    { id: 'today', icon: 'Sun', label: 'Hoy' },
    { id: 'workout', icon: 'Dumbbell', label: 'Entreno' },
    { id: 'progress', icon: 'Chart', label: 'Progreso' },
    { id: 'health', icon: 'Heart', label: 'Salud' },
    { id: 'profile', icon: 'User', label: 'Perfil' },
  ];
  return (
    <div className="tab-bar">
      <div className="tb-inner">
        {tabs.map(t => {
          const Cmp = Icon[t.icon];
          return (
            <button
              key={t.id}
              className={'tab-btn ' + (active === t.id ? 'active' : '')}
              onClick={() => setActive(t.id)}
            >
              <Cmp size={18} />
              <span className="tb-label">{t.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Sheet / Modal ───
function Sheet({ open, onClose, children, title }) {
  if (!open) return null;
  return (
    <div className="sheet-overlay" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="sheet-handle" />
        {title && (
          <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 24, marginBottom: 14 }}>
            {title}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

// ─── Sparkline (svg) ───
function Sparkline({ data, color = '#FAB940', height = 60, width = 280 }) {
  const max = Math.max(...data.map(d => d.v));
  const min = Math.min(...data.map(d => d.v));
  const range = max - min || 1;
  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((d.v - min) / range) * (height - 10) - 5;
    return [x, y];
  });
  const pathLine = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p.join(' ')).join(' ');
  const pathArea = pathLine + ` L ${width} ${height} L 0 ${height} Z`;
  return (
    <svg width={width} height={height + 30} viewBox={`0 0 ${width} ${height + 30}`} style={{ overflow: 'visible' }}>
      <defs>
        <linearGradient id="sparkArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.4"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={pathArea} fill="url(#sparkArea)" />
      <path d={pathLine} fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => (
        <g key={i}>
          <circle cx={p[0]} cy={p[1]} r={i === pts.length - 1 ? 4 : 2.5} fill={color} />
          {i === pts.length - 1 && <circle cx={p[0]} cy={p[1]} r={8} fill={color} opacity="0.2" />}
          <text x={p[0]} y={height + 16} fill="rgba(247,217,252,0.45)"
                fontFamily="Space Mono, monospace" fontSize="9" textAnchor="middle">
            {data[i].d}
          </text>
        </g>
      ))}
    </svg>
  );
}

// ─── Bar Chart ───
function BarChart({ data, width = 280, height = 90, color = '#E94F8B' }) {
  const max = Math.max(...data.map(d => d.v), 1);
  const bw = width / data.length - 6;
  return (
    <svg width={width} height={height + 24} viewBox={`0 0 ${width} ${height + 24}`}>
      {data.map((d, i) => {
        const h = (d.v / max) * (height - 8);
        const x = i * (bw + 6);
        const y = height - h;
        return (
          <g key={i}>
            <rect x={x} y={y} width={bw} height={h} rx="3" fill={color} opacity={d.v ? 1 : 0.2}/>
            <text x={x + bw / 2} y={height + 14} fill="rgba(247,217,252,0.5)"
                  fontFamily="Space Mono, monospace" fontSize="9" textAnchor="middle">{d.d}</text>
          </g>
        );
      })}
    </svg>
  );
}

Object.assign(window, { SparkleField, StatusBar, Star, DateStrip, TabBar, Sheet, Sparkline, BarChart });
