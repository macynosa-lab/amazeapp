// Mock data for App Hábitos

// ─── Supplement protocol (per program day) ─────────────────────────
// Phase 1 (Sem 1 Inicio · Días 1-3): probiotic ×2 + magnesio
// Phase 2 (Sem 1 Expansión · Días 4-9): + glutamina, D3 (d7), Vit A (d9), krill, salmon, cúrcuma
// Phase 3 (Sem 2 Stack · Días 10-14): + glicina (d10), hierro alt (d11/13), kelp (d12)
function suppsForDay(programDay) {
  const out = [];
  const ironAltDay = programDay >= 11 && programDay % 2 === 1; // d11, d13
  const phase = programDay <= 3 ? 1 : programDay <= 9 ? 2 : 3;

  // 06:30 — Hierro (sólo días alternos desde d11) — antes de glutamina
  if (ironAltDay) {
    out.push({ id: 'hierro', time: '06:30', name: 'NOW Iron Bisglicinato', dose: '18 mg · en ayunas total', tag: 'días alternos', emoji: '🩸' });
    out.push({ id: 'vitc',   time: '06:30', name: 'NOW Vit C-1000 (½ cápsula)', dose: '500 mg · con hierro', tag: 'sinergia', emoji: '🍋' });
  }

  // 07:00 — Glutamina en ayunas (entra Día 4)
  if (phase >= 2) {
    out.push({ id: 'glut', time: '07:00', name: 'GAT L-Glutamina', dose: '5 g en 200ml agua tibia', tag: 'ayunas', emoji: '🌿' });
  }

  // 07:30 — Desayuno con grasa
  out.push({ id: 'pro1', time: '07:30', name: 'S. Boulardii (1ª dosis)', dose: '1 cápsula · 5 B CFU', tag: 'diario', emoji: '🦠' });
  if (programDay >= 7) {
    out.push({ id: 'd3',   time: '07:30', name: 'Vito Vitamina D3', dose: '4,000 UI · con grasa', tag: 'diario', emoji: '☀️' });
  }
  if (programDay >= 9) {
    out.push({ id: 'vita', time: '07:30', name: 'B Life Vitamina A', dose: '3,333 UI · palmitato retinol', tag: 'diario', emoji: '🟠' });
  }
  if (phase >= 2) {
    out.push({ id: 'krill', time: '07:30', name: 'Krill Antártica', dose: '1 cápsula · EPA + DHA', tag: 'diario', emoji: '🐟' });
  }
  if (programDay >= 12) {
    out.push({ id: 'kelp', time: '07:30', name: 'NOW Kelp (Yodo)', dose: '150–220 mcg', tag: 'tiroides', emoji: '🌊' });
  }

  // 13:00 — Comida principal
  out.push({ id: 'pro2', time: '13:00', name: 'S. Boulardii (2ª dosis)', dose: '1 cápsula · con comida', tag: 'diario', emoji: '🦠' });
  if (phase >= 2) {
    out.push({ id: 'salmon', time: '13:00', name: 'Salmon Oil B Life', dose: '1 cápsula · omega-3', tag: 'diario', emoji: '🐠' });
    out.push({ id: 'curc',   time: '13:00', name: 'Cúrcuma + pimienta',     dose: '¼ cdita + pizca', tag: 'antinflam.', emoji: '🌶️' });
  }

  // 21:00 — Cena / antes de dormir
  if (phase >= 3) {
    out.push({ id: 'glyc', time: '21:00', name: 'Nutricost Glicina', dose: '3 g en agua · con cena', tag: 'detox', emoji: '🌿' });
  }
  out.push({ id: 'mag', time: '21:30', name: 'Nutricost Mg Bisglicinato', dose: '420 mg elemental', tag: 'sueño', emoji: '🌙' });

  return out;
}

function suppsForDayWithStatus(programDay, opts = {}) {
  const { allTaken = false, takenUntilTime = null, markNext = false } = opts;
  const list = suppsForDay(programDay);
  return list.map((s, i) => {
    let taken = allTaken;
    if (takenUntilTime !== null && s.time <= takenUntilTime) taken = true;
    return { ...s, taken, next: false };
  }).map((s, i, arr) => {
    if (!markNext) return s;
    const firstUntaken = arr.findIndex(x => !x.taken);
    return { ...s, next: i === firstUntaken };
  });
}

// program day for each calendar day in our week (today = Mar 12 May = Día 9)
const PROGRAM_DAY_BY_NUM = { 11: 8, 12: 9, 13: 10, 14: 11, 15: 12, 16: 13, 17: 14 };

const DATA = {
  user: { name: 'Macy', age: 30, fcMax: 190 },
  today: {
    date: new Date(2026, 4, 12), // May 12, 2026 (Tue)
    dayNum: 9,
    week: 2,
    workout: {
      id: 'w2d2', type: 'Cardio Z2', icon: 'cardio',
      duration: 45, rpe: '5-6', fc: '114–125',
      exercises: [
        { name: 'Caminadora Z2', detail: 'Inclinación 5%, 4.5–5 km/h', kind: 'cardio', sets: 1, target: '45 min · 114–125 lpm' },
        { name: 'Activación glúteos', detail: 'Clamshells + puentes', kind: 'strength', sets: 3, reps: '15', tool: 'Polainas 1kg' },
        { name: 'Soleus push-ups', detail: 'En pausa de trabajo', kind: 'mobility', sets: 3, reps: '60s' },
      ],
    },
    supps: suppsForDayWithStatus(9, { takenUntilTime: '07:30', markNext: true }),
    anchors: [
      { id: 'a1', icon: 'Sun', label: 'Luz solar 10–30 min', done: true },
      { id: 'a2', icon: 'Water', label: '2 L de agua', done: false, progress: 0.6 },
      { id: 'a3', icon: 'Walk', label: 'Caminata post-comida', done: false },
      { id: 'a4', icon: 'Wind', label: 'Respiración matinal', done: true },
      { id: 'a5', icon: 'Clock', label: 'Pausa activa c/50min', done: false },
      { id: 'a6', icon: 'Moon', label: 'Dormir 22:30', done: false },
      { id: 'a7', icon: 'Notebook', label: 'Hojas matutinas', done: true },
      { id: 'a8', icon: 'Apple', label: 'Ventana 8:00–20:00', done: true },
    ],
  },
  week: [
    { dow: 'L', num: 11, dayLabel: 'Lunes',     dateLabel: '11 mayo', type: 'fuerza', kind: 'Fuerza A',  done: true,  workouts: 1, supps: 7,
      title: 'Fuerza A',        subtitle: 'Full body · cadena posterior',
      meta: '45 MIN · RPE 5-6 · 7 EJERCICIOS', past: true },
    { dow: 'M', num: 12, dayLabel: 'Martes',    dateLabel: '12 mayo', type: 'cardio', kind: 'Cardio Z2', done: false, workouts: 0, supps: 2, today: true,
      title: 'Cardio · Zona 2', subtitle: 'Caminadora + activación glúteos',
      meta: '45 MIN · RPE 5-6 · 114–125 LPM' },
    { dow: 'X', num: 13, dayLabel: 'Miércoles', dateLabel: '13 mayo', type: 'fuerza', kind: 'Fuerza B',  done: false, workouts: 0, supps: 0,
      title: 'Fuerza B',        subtitle: 'Tracción + pierna unilateral',
      meta: '45 MIN · RPE 6 · 7 EJERCICIOS' },
    { dow: 'J', num: 14, dayLabel: 'Jueves',    dateLabel: '14 mayo', type: 'yoga',   kind: 'Pilates',  done: false, workouts: 0, supps: 0,
      title: 'Pilates de piso', subtitle: 'Glúteos + core profundo',
      meta: '35 MIN · POLAINAS 1 KG' },
    { dow: 'V', num: 15, dayLabel: 'Viernes',   dateLabel: '15 mayo', type: 'cardio', kind: 'Cardio Z2', done: false, workouts: 0, supps: 0,
      title: 'Cardio · Zona 2', subtitle: 'Z2 + activación de glúteos',
      meta: '50 MIN · RPE 5-6' },
    { dow: 'S', num: 16, dayLabel: 'Sábado',    dateLabel: '16 mayo', type: 'hiking', kind: 'Hiking',   done: false, workouts: 0, supps: 0,
      title: 'Hiking',          subtitle: 'Terreno con pendiente suave',
      meta: '70 MIN · Z2-3 CONVERSACIONAL' },
    { dow: 'D', num: 17, dayLabel: 'Domingo',   dateLabel: '17 mayo', type: 'rest',   kind: 'Descanso',  done: false, workouts: 0, supps: 0,
      title: 'Descanso activo', subtitle: 'Yin yoga · paseo · planificación',
      meta: '20-30 MIN · OPCIONAL' },
  ],
  progress: {
    weekly: { workouts: 1, workoutsGoal: 6, supps: 0.84, anchors: 0.62, streak: 12 },
    weight: [
      { d: 'Sem 1', v: 72.4 },
      { d: 'Sem 2', v: 72.1 },
      { d: 'Sem 3', v: 71.6 },
      { d: 'Sem 4', v: 71.2 },
      { d: 'Sem 5', v: 70.8 },
      { d: 'Sem 6', v: 70.5 },
      { d: 'Hoy',   v: 70.1 },
    ],
    monthlyAchievements: [
      { title: 'Primera semana completa', sub: 'Mes 1 · Semana 1', icon: 'Trophy' },
      { title: '7 días de luz solar', sub: 'Ancla matinal', icon: 'Sun' },
      { title: 'Hidratación · 14 días', sub: '2L consistente', icon: 'Water' },
    ],
  },
  body: {
    weight: { current: 70.1, prev: 72.4, unit: 'kg', delta: -2.3 },
    inbody: {
      fat:    { value: 28.4, prev: 31.2, unit: '%', good: 'down' },
      muscle: { value: 26.8, prev: 25.9, unit: 'kg', good: 'up' },
      water:  { value: 52.1, prev: 50.4, unit: '%', good: 'up' },
      visc:   { value: 7,    prev: 9,    unit: 'lvl', good: 'down' },
    },
    measures: [
      { name: 'Cintura', value: 78, prev: 82.5, unit: 'cm' },
      { name: 'Cadera',  value: 102, prev: 104, unit: 'cm' },
      { name: 'Muslo',   value: 58, prev: 60.5, unit: 'cm' },
      { name: 'Brazo',   value: 28, prev: 28, unit: 'cm' },
      { name: 'Pecho',   value: 92, prev: 93, unit: 'cm' },
    ],
    labs: [
      { name: 'Glucosa en ayunas', value: 91,  unit: 'mg/dL', range: '70–99',   status: 'optimal', prev: 108, date: 'Abr 28' },
      { name: 'HOMA-IR',           value: 2.1, unit: '',      range: '<2.5',     status: 'optimal', prev: 4.2, date: 'Abr 28' },
      { name: 'Triglicéridos',     value: 132, unit: 'mg/dL', range: '<150',     status: 'optimal', prev: 198, date: 'Abr 28' },
      { name: 'ALT (hígado)',      value: 28,  unit: 'U/L',   range: '7–35',     status: 'optimal', prev: 48,  date: 'Abr 28' },
      { name: 'AST (hígado)',      value: 24,  unit: 'U/L',   range: '8–33',     status: 'optimal', prev: 36,  date: 'Abr 28' },
      { name: 'Vitamina D',        value: 22,  unit: 'ng/mL', range: '30–80',    status: 'low',     prev: 18,  date: 'Abr 28' },
      { name: 'Hierro sérico',     value: 65,  unit: 'µg/dL', range: '60–170',   status: 'optimal', prev: 52,  date: 'Abr 28' },
      { name: 'Ferritina',         value: 18,  unit: 'ng/mL', range: '15–150',   status: 'watch',   prev: 12,  date: 'Abr 28' },
    ],
  },
  tools: ['Peso corporal', 'Bandas', 'Ligas', 'Polainas 1kg', 'Pesas', 'Pelota pilates'],
};

window.DATA = DATA;
window.suppsForDay = suppsForDay;
window.suppsForDayWithStatus = suppsForDayWithStatus;
window.PROGRAM_DAY_BY_NUM = PROGRAM_DAY_BY_NUM;
