// Profile screen — fully functional configuration
function ProfileScreen() {
  const { state, actions } = useApp();
  const [sheet, setSheet] = useState(null); // 'notifications' | 'connections' | 'goals' | 'reminders' | 'personal'

  const p = state.profile;
  const activeAlarms = Object.values(state.suppsByDay)
    .flat()
    .filter(s => s.alarmOn).length;

  const items = [
    {
      i: 'Bell', t: 'Notificaciones', s: `${activeAlarms} alarmas activas`,
      go: 'notifications',
    },
    {
      i: 'Heart', t: 'Conexiones', s: connectionsLabel(p.connections),
      go: 'connections',
    },
    {
      i: 'Trophy', t: 'Metas y rangos', s: `peso meta ${p.goalWeight} kg · ${p.programTotal} sem`,
      go: 'goals',
    },
    {
      i: 'Settings', t: 'Recordatorios', s: remindersLabel(p.reminders),
      go: 'reminders',
    },
    {
      i: 'User', t: 'Datos personales', s: `${p.age} años · fc máx ${p.fcMax}`,
      go: 'personal',
    },
  ];

  return (
    <>
      <div className="scroll">
        <div className="app-header">
          <div className="head-left">
            <span className="head-eyebrow">Tu perfil</span>
            <h1 style={{ fontSize: 36 }}>
              <span style={{ fontStyle: 'italic' }}>{p.name.toLowerCase()}</span><span className="accent">.</span>
            </h1>
            <span className="head-date">programa · {p.programTotal} semanas · sem {p.programWeek}</span>
          </div>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--rose-glow), var(--bordeaux))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 24, color: 'white',
            boxShadow: '0 6px 16px rgba(194,40,107,0.4), inset 0 1px 0 rgba(255,255,255,0.35)',
          }}>{p.name[0]}</div>
        </div>

        <div style={{ padding: '14px 18px 0' }}>
          <div className="card-dark" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--gold)', textTransform: 'uppercase' }}>
              Objetivo · {p.programTotal} semanas
            </div>
            <div style={{ fontFamily: 'var(--fs-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--lavender)', marginTop: 4, lineHeight: 1.15 }}>
              {p.goal}
            </div>
            <div style={{ marginTop: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.1em', color: 'var(--muted)', marginBottom: 6 }}>
                <span>SEMANA {p.programWeek} / {p.programTotal}</span>
                <span style={{ color: 'var(--gold)' }}>{Math.round((p.programWeek / p.programTotal) * 100)}%</span>
              </div>
              <div className="progress"><div className="fill" style={{ width: `${(p.programWeek / p.programTotal) * 100}%` }}/></div>
            </div>
          </div>
        </div>

        <div className="section-head"><span className="label">Configuración</span></div>
        <div className="pad" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {items.map((r, i) => {
            const Cmp = Icon[r.i] || Icon.Settings;
            return (
              <button key={i} onClick={() => setSheet(r.go)} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 14px', borderRadius: 14, textAlign: 'left',
                background: 'rgba(247,217,252,0.04)',
                border: '1px solid var(--hairline-2)',
              }}>
                <div style={{
                  width: 34, height: 34, borderRadius: 10,
                  background: 'rgba(247,217,252,0.08)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--gold)',
                }}><Cmp size={16}/></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, color: 'var(--lavender)', fontWeight: 500 }}>{r.t}</div>
                  <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.05em', marginTop: 2 }}>{r.s}</div>
                </div>
                <Icon.Chevron size={14} color="rgba(247,217,252,0.4)"/>
              </button>
            );
          })}
        </div>

        <div className="section-head"><span className="label">Cuenta</span></div>
        <div className="pad" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <button onClick={() => {
            if (confirm('¿Restablecer toda la app a sus valores iniciales?')) {
              actions.resetAll();
            }
          }} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 14px', borderRadius: 14, textAlign: 'left',
            background: 'rgba(233,79,139,0.06)',
            border: '1px solid rgba(233,79,139,0.2)',
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: 'rgba(233,79,139,0.12)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--rose-glow)',
            }}><Icon.Sync size={16}/></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, color: 'var(--rose-glow)', fontWeight: 500 }}>Restablecer datos</div>
              <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.05em', marginTop: 2 }}>borra tu progreso local</div>
            </div>
          </button>
        </div>

        <div style={{ padding: '24px 18px 0' }}>
          <div style={{ textAlign: 'center', fontFamily: 'var(--fs-mono)', fontSize: 9.5, letterSpacing: '0.16em', color: 'var(--muted)', textTransform: 'uppercase' }}>
            ✦ app hábitos · v0.9 · y2k ✦
          </div>
        </div>
      </div>

      {sheet === 'notifications' && <NotificationsSheet onClose={() => setSheet(null)}/>}
      {sheet === 'connections'   && <ConnectionsSheet onClose={() => setSheet(null)}/>}
      {sheet === 'goals'         && <GoalsSheet onClose={() => setSheet(null)}/>}
      {sheet === 'reminders'     && <RemindersSheet onClose={() => setSheet(null)}/>}
      {sheet === 'personal'      && <PersonalSheet onClose={() => setSheet(null)}/>}
    </>
  );
}

// ─── helpers ───
function connectionsLabel(c) {
  const on = [];
  if (c.health) on.push('Apple Health');
  if (c.watch)  on.push('iWatch');
  if (c.scale)  on.push('Báscula');
  return on.length ? on.join(' · ') : 'sin conexiones';
}
function remindersLabel(r) {
  const on = [];
  if (r.rest) on.push('descansos');
  if (r.hydration) on.push('hidratación');
  if (r.posture) on.push('postura');
  if (r.sleep) on.push('sueño');
  return on.length ? on.join(', ') : 'desactivado';
}

// ─── Notifications ───
function NotificationsSheet({ onClose }) {
  const { state, actions } = useApp();
  const n = state.profile.notifications;

  return (
    <Sheet open={true} onClose={onClose} title="Notificaciones">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        cómo recibes las alertas
      </div>
      <div className="hairline"/>

      <ToggleRow title="Notificaciones push" sub="banners en tu pantalla"
        on={n.push} onChange={v => actions.updateProfileSection('notifications', { push: v })}/>
      <ToggleRow title="Sonido suave" sub="campana zen al sonar"
        on={n.sound} onChange={v => actions.updateProfileSection('notifications', { sound: v })}/>
      <ToggleRow title="Vibración" sub="pulso ligero"
        on={n.vibration} onChange={v => actions.updateProfileSection('notifications', { vibration: v })}/>
      <ToggleRow title="Resumen diario" sub="cada noche · 22:00"
        on={n.summary} onChange={v => actions.updateProfileSection('notifications', { summary: v })}/>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={onClose}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

// ─── Connections ───
function ConnectionsSheet({ onClose }) {
  const { state, actions } = useApp();
  const c = state.profile.connections;

  return (
    <Sheet open={true} onClose={onClose} title="Conexiones">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        sincroniza tus dispositivos
      </div>
      <div className="hairline"/>

      <ToggleRow title="Apple Health" sub="lee tu actividad y peso"
        on={c.health} onChange={v => actions.updateProfileSection('connections', { health: v })}/>
      <ToggleRow title="Apple Watch" sub="entrenos, fc y sueño"
        on={c.watch} onChange={v => actions.updateProfileSection('connections', { watch: v })}/>
      <ToggleRow title="Báscula inteligente" sub="peso · grasa · músculo"
        on={c.scale} onChange={v => actions.updateProfileSection('connections', { scale: v })}/>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={onClose}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

// ─── Goals ───
function GoalsSheet({ onClose }) {
  const { state, actions } = useApp();
  const [form, setForm] = useState({
    goal: state.profile.goal,
    goalWeight: state.profile.goalWeight,
    programTotal: state.profile.programTotal,
    programWeek: state.profile.programWeek,
  });

  const save = () => {
    actions.updateProfile(form);
    onClose();
  };

  return (
    <Sheet open={true} onClose={onClose} title="Metas y rangos">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        ajusta tu objetivo y horizonte
      </div>
      <div className="hairline"/>

      <FormField label="Objetivo">
        <input value={form.goal} onChange={e => setForm({ ...form, goal: e.target.value })}
          style={{ textAlign: 'left' }}/>
      </FormField>

      <FormField label="Peso meta · kg">
        <input type="number" value={form.goalWeight}
          onChange={e => setForm({ ...form, goalWeight: +e.target.value })}/>
      </FormField>

      <FormField label="Duración · semanas">
        <input type="number" value={form.programTotal}
          onChange={e => setForm({ ...form, programTotal: +e.target.value })}/>
      </FormField>

      <FormField label="Semana actual">
        <input type="number" value={form.programWeek}
          onChange={e => setForm({ ...form, programWeek: +e.target.value })}/>
      </FormField>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={save}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

// ─── Reminders ───
function RemindersSheet({ onClose }) {
  const { state, actions } = useApp();
  const r = state.profile.reminders;

  return (
    <Sheet open={true} onClose={onClose} title="Recordatorios">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        anclas que te recuerdan al día
      </div>
      <div className="hairline"/>

      <ToggleRow title="Pausas de descanso" sub="cada 50 min · postura"
        on={r.rest} onChange={v => actions.updateProfileSection('reminders', { rest: v })}/>
      <ToggleRow title="Hidratación" sub="cada 90 min · 2L meta"
        on={r.hydration} onChange={v => actions.updateProfileSection('reminders', { hydration: v })}/>
      <ToggleRow title="Postura" sub="corrige cada 30 min"
        on={r.posture} onChange={v => actions.updateProfileSection('reminders', { posture: v })}/>
      <ToggleRow title="Hora de dormir" sub="22:30 · ventana melatonina"
        on={r.sleep} onChange={v => actions.updateProfileSection('reminders', { sleep: v })}/>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={onClose}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

// ─── Personal data ───
function PersonalSheet({ onClose }) {
  const { state, actions } = useApp();
  const p = state.profile;
  const [form, setForm] = useState({
    name: p.name, age: p.age, height: p.height, fcMax: p.fcMax,
    allergies: p.personal.allergies,
    conditions: p.personal.conditions,
    meds: p.personal.meds,
  });

  const save = () => {
    actions.updateProfile({
      name: form.name, age: +form.age, height: +form.height, fcMax: +form.fcMax,
      personal: { allergies: form.allergies, conditions: form.conditions, meds: form.meds },
    });
    onClose();
  };

  return (
    <Sheet open={true} onClose={onClose} title="Datos personales">
      <div style={{ fontFamily: 'var(--fs-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 4 }}>
        información clínica básica
      </div>
      <div className="hairline"/>

      <FormField label="Nombre">
        <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} style={{ textAlign: 'left' }}/>
      </FormField>
      <FormField label="Edad">
        <input type="number" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })}/>
      </FormField>
      <FormField label="Estatura · cm">
        <input type="number" value={form.height} onChange={e => setForm({ ...form, height: e.target.value })}/>
      </FormField>
      <FormField label="FC máx · lpm">
        <input type="number" value={form.fcMax} onChange={e => setForm({ ...form, fcMax: e.target.value })}/>
      </FormField>

      <div className="hairline"/>

      <FormField label="Alergias">
        <input value={form.allergies} onChange={e => setForm({ ...form, allergies: e.target.value })} style={{ textAlign: 'left' }}/>
      </FormField>
      <FormField label="Condiciones">
        <input value={form.conditions} onChange={e => setForm({ ...form, conditions: e.target.value })} style={{ textAlign: 'left' }}/>
      </FormField>
      <FormField label="Medicamentos">
        <input value={form.meds} onChange={e => setForm({ ...form, meds: e.target.value })} style={{ textAlign: 'left' }}/>
      </FormField>

      <button className="btn primary btn-block" style={{ marginTop: 14 }} onClick={save}>
        <Icon.Check size={14}/> Guardar
      </button>
    </Sheet>
  );
}

// ─── Toggle row helper ───
function ToggleRow({ title, sub, on, onChange }) {
  return (
    <div className="row">
      <div className="row-main">
        <div className="row-title">{title}</div>
        {sub && <div className="row-sub">{sub}</div>}
      </div>
      <Toggle on={on} onChange={onChange}/>
    </div>
  );
}

window.ProfileScreen = ProfileScreen;
